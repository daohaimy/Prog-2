//Mehrwertsteuer in %
static const float MWST = 1.19;

void berechneBruttoPreise(float netto, float& brutto) {
    brutto = netto * MWST;
}
