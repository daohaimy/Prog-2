#pragma once

//In der Header-Datei muss der Funktionsprototyp stehen. Dazu später mehr
void berechneBruttoPreise(float netto, float& brutto);
