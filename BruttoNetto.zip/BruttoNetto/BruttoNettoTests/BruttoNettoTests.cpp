#include "gtest/gtest.h"
#include "../BruttoNettoBerechnung.h"

TEST(BRUTTONETTO, BruttoBerechnungReferenzParameter) {
    float netto = 2.4;
    float brutto = 0.0;

    /*
     * Dieser Test prüft, ob der zweite Parameter von der Funktion berechneBruttoPreise
     * als Referenz übergeben wird. Anders als in Java, werden in C++ alle Variablen
     * und Objekte standardmäßig als Wert und nicht als Referenz übergeben.
     * Möchte man einen Wert als Referenz übergeben, muss an den Datentypen das &-Zeichen
     * angehängt werden!
     * Auch anders als in Java, können in C++ auch primitive Datentypen, wie float, als Referenz
     * übergeben werden. Dazu später in der Vorlesung mehr.
     *
     * Damit dieser Test also bestanden werden kann, müssen Sie in den Dateien BruttoNettoBerechnung.cpp/.h
     * die Funktionssignatur von berechneBruttoPreise wie folgt ändern:
     *
     * vorher: void berechneBruttoPreise(float netto, float brutto)
     * nachher: void berechneBruttoPreise(float netto, float& brutto)
     *                                                      ^
     *
     * Hinweis: Beachten Sie auch, dass die IDE (zumindest CLion) den Parameter anders einfärbt
     * und Warnungen produziert, wenn der Parameter NICHT als Referenz übergeben wird
     */

    berechneBruttoPreise(netto, brutto);

    //Prüft nur, ob der Nettowert geändert wurde. Nicht, ob er korrekt geändert wurde
    //ASSERT_NE bedeutet so viel wie: ANNAHME, NICHT GLEICH (NE = not equal)
    ASSERT_NE(brutto, 0.0);
}

TEST(BRUTTONETTO, BruttoBerechnungKorrekt) {
    float brutto = 0.0;

    /*
     * Hier wird die korrekte Berechnung getestet.
     * Einmal kurz überlegt und wir erinnern uns daran, dass 1.0 Euro Netto mit Mehrwertsteuer 1.19 Euro Brutto sind
     */

    berechneBruttoPreise(1.0, brutto);
    //ASSERT_NEAR prüft, ob die Variable brutto in der Nähe von 1.19 ist mit einer erlaubten Abweichung von 0.01
    ASSERT_NEAR(brutto, 1.19, 0.01);
    berechneBruttoPreise(3.6, brutto);
    ASSERT_NEAR(brutto, 4.28, 0.01);
}

TEST(BRUTTONETTO, TestMain) {
    /*
     * Wenn die Referenz und die Berechnung richtig durchgeführt wird, können Sie
     * die "Run Configuration" auf das Hauptprogramm "BruttoNetto"
     * stellen. Damit wird die Funktion main() in "main.cpp" ausgeführt.
     *
     * Die main() Funktion hat noch einen Fehler, der an dieser Stelle nicht getestet werden kann.
     * Darum ist der Test leer und schlägt manuell immer fehl.
     *
     * Um den Fehler zu finden, ist der Debugger ein sehr (SEHR!!) hilfreiches Werkzeug.
     * Setzen Sie in der main() Funktion an einer Stelle einen Breakpoint und gehen Sie das Programm
     * Schritt-für-Schritt durch... Viel Erfolg :-)
     *
     * Wenn Sie den Fehler gefunden haben, können Sie die folgende Codezeile auskommentieren.
     */
    ASSERT_TRUE(true);
}