Einführung ins Praktikum Prog 2  
==
Das Programm ButtoNetto addiert auf eine Liste von Nettopreisen die Mehrwertsteuer und gibt diese auf
der Konsole aus. Das Programm hat einige Fehler und funktioniert nicht korrekt. Mithilfe der mitgelieferten Testfälle
und des Debuggers sollen Sie diese Fehler finden und beheben.

 Das Programm hat 2 Run-Configurations:
  - "BruttoNetto": hier befindet sich die main()-Funktion des Programms
  - "BruttoNettoWithTests": hier befinden sich die Tests

Beginnen Sie mit den Testfällen und der BruttoNettoWithTests Run-Configuration. 

Struktur des Projektes:
- BruttoNettoWithTests: GIT-Submodule mit Tests
  - BruttoNettoTests.cpp: Hier sind die Testfälle
- cmake-build-debug: Ordner für Ausgabedateien des Compilers
- googletest: GIT-Submodule mit Google Testinfrastruktur
- .gitignore: Textdatei, um GIT mitzuteilen, welchen Dateien ignoriert werden sollen
- .gitmodules: Textdatei, hier sind alle Submodule eingetragen
- BruttoNettoBerechnung.cpp: Hier befindet sich die Definition der Funktion berechneNettoPreis()
- BruttoNettoBerechnung.h: Hier ist die Funktion berechneNettoPreise() deklariert, um Sie für andere CPP-Dateien nutzbar zu machen
- main.cpp: Hauptfunktion main()
- README.md: Diese README-Datei 