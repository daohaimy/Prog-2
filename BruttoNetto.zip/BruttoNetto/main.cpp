#include <iostream>
#include <iomanip>

#include "BruttoNettoBerechnung.h"

using namespace std;

int main()
{
    const int ANZAHL = 3;
    float netto[] = {1.5, 2.6, 3.8};
    float brutto[ANZAHL];

    for(int i = 0; i < ANZAHL; i++) {
        berechneBruttoPreise(netto[i], brutto[i]);
    }

    //Ausgabe der berechneten Werte
    cout << fixed << setprecision(2) << netto[0] << " EUR - " << brutto[0] << " EUR" << endl;
    cout << fixed << setprecision(2) << netto[1] << " EUR - " << brutto[1] << " EUR" << endl;
    cout << fixed << setprecision(2) << netto[2] << " EUR - " << brutto[2] << " EUR" << endl;

    return 0;
}
