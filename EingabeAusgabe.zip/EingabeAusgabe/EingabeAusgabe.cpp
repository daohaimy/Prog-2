#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>

using namespace std;

bool EingabeAusgabe(const string& eingabeDatei, const string& ausgabeDatei) {
    ifstream ein(eingabeDatei);
    ofstream aus(ausgabeDatei);
    if (!ein || !aus) {
        cout << "Fehler beim Oeffnen der Dateien" << endl;
        return false;
    }

    int ersteSpalte;
    double zweiteSpalte;
    string dritteSpalte;
    string reihen;
    stringstream zeile;

    int i = 1;
    //while (!(ein >> ersteSpalte >> zweiteSpalte >> dritteSpalte).eof()) {
        while(getline(ein, reihen)){
            zeile << reihen;
            zeile >> ersteSpalte >> zweiteSpalte >> dritteSpalte;
        if(!zeile.fail()){
            aus << i << ". | " << setw(4) << setfill('0') << hex << ersteSpalte << " | " << setw(6) << zweiteSpalte << " | " << right << setw(15) << setfill('-')
                << dritteSpalte << endl;
            i++;
        }
        zeile.clear();

    }
}

