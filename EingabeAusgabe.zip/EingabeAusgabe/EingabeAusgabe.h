#pragma once

#include <string>

using namespace std;

bool EingabeAusgabe(const string& eingabeDatei, const string& ausgabeDatei);