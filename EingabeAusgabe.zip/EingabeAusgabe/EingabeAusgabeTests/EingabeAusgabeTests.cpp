#include <fstream>

#include "gtest/gtest.h"
#include "../EingabeAusgabe.h"

const string dateiKorrekt = "../EingabeAusgabeTests/eingabe.txt";
const string dateiNichtVorhanden = "foobar.txt";
const string dateiFehlerhaft = "../EingabeAusgabeTests/eingabe_fehler.txt";
const string dateiAusgabe = "../ausgabe.txt";

TEST(EINGABE_AUSGABE, DateiKonvertierenRueckgabeWertFalse) {
    bool result;

    //Die Funktion muss false zurückgeben, wenn die Datei nicht geöffnet werden kann.
    //Die Datei "foobar.txt" existiert nicht!
    result = EingabeAusgabe(dateiNichtVorhanden, dateiAusgabe);
    ASSERT_FALSE(result);
}

TEST(EINGABE_AUSGABE, DateiKonvertierenRueckgabeWertTrue) {
    bool result;

    //Die Funktion soll true zurückgeben, wenn die Konvertierung erfolgreich war.
    result = EingabeAusgabe(dateiKorrekt, dateiAusgabe);
    ASSERT_TRUE(result);
}

TEST(EINGABE_AUSGABE, DateiKonvertierenDateiVorhanden) {
    bool result;

    result = EingabeAusgabe(dateiKorrekt, dateiAusgabe);
    ASSERT_TRUE(result);

    //Datei muss existieren und geöffnet werden können
    ifstream file(dateiAusgabe);
    ASSERT_TRUE(file.is_open());
    file.close();
}

TEST(EINGABE_AUSGABE, DateiKonvertierenInhaltKorrekt) {
    bool result;

    result = EingabeAusgabe(dateiKorrekt, dateiAusgabe);
    ASSERT_TRUE(result);

    ifstream file(dateiAusgabe);
    ASSERT_TRUE(file.is_open());

    string line;

    getline(file, line); ASSERT_STREQ(line.c_str(), "1. | 053f | 4.23423 | ------HalloWelt");
    getline(file, line); ASSERT_STREQ(line.c_str(), "2. | 85ba | 4323.12 | --C++machtSpass");
    getline(file, line); ASSERT_STREQ(line.c_str(), "3. | ffaf | 4.30658 | --------Testing");
    getline(file, line); ASSERT_STREQ(line.c_str(), "4. | 0d54 | 1.23457 | abcderfghijklmn");
    getline(file, line); ASSERT_STREQ(line.c_str(), "5. | ffff | 5.36209 | ----Hexadezimal");
    getline(file, line); ASSERT_STREQ(line.c_str(), "6. | 7e56 | 3423.34 | -----Referenzen");
    getline(file, line); ASSERT_STREQ(line.c_str(), "7. | 266a | 9.93434 | --------yxzuerf");
    getline(file, line); ASSERT_STREQ(line.c_str(), "8. | 0ca2 | 9883.32 | -ABCDERFGHIJKLM");
    getline(file, line); ASSERT_STREQ(line.c_str(), "9. | 00d5 | 3.14159 | -------Beispiel");

    file.close();
}

TEST(EINGABE_AUSGABE, DateiKonvertierenInhaltFehlerhaft) {
    bool result;

    //Das Konvertieren einer fehlerhaften Datei soll so gut es geht durchgeführt werden.
    //Es kann z.B. eine Meldung auf der Konsole erscheinen, dass eine Zeile defekt ist.
    //Eine fehlerhafte Zeile soll nicht in der Ausgabedatei vorkommen

    result = EingabeAusgabe(dateiFehlerhaft, dateiAusgabe);
    ASSERT_TRUE(result);

    ifstream file(dateiAusgabe);
    ASSERT_TRUE(file.is_open());

    string line;

    //In der fehlerhaften Datei fehlt ein Token in Zeile 3.
    //Diese Zeile soll in der Ausgabe einfach ausgelassen werden.
    //Die Nummerierung soll weiterhin fortlaufend sein.

    getline(file, line); ASSERT_STREQ(line.c_str(), "1. | 053f | 4.23423 | ------HalloWelt");
    getline(file, line); ASSERT_STREQ(line.c_str(), "2. | 85ba | 4323.12 | --C++machtSpass");
//    getline(file, line); ASSERT_STREQ(line.c_str(), "3. | ffaf | 4.30658 | --------Testing");
    getline(file, line); ASSERT_STREQ(line.c_str(), "3. | 0d54 | 1.23457 | abcderfghijklmn");
    getline(file, line); ASSERT_STREQ(line.c_str(), "4. | ffff | 5.36209 | ----Hexadezimal");
    getline(file, line); ASSERT_STREQ(line.c_str(), "5. | 7e56 | 3423.34 | -----Referenzen");
    getline(file, line); ASSERT_STREQ(line.c_str(), "6. | 266a | 9.93434 | --------yxzuerf");
    getline(file, line); ASSERT_STREQ(line.c_str(), "7. | 0ca2 | 9883.32 | -ABCDERFGHIJKLM");
    getline(file, line); ASSERT_STREQ(line.c_str(), "8. | 00d5 | 3.14159 | -------Beispiel");

    file.close();
}
