#include "FIFO.hpp"
using namespace std;
#include <string>

Fifo::Fifo(){
    top = nullptr;
}

Fifo& Fifo:: operator << (const string& objekt){
    groesse++;
    if(top == nullptr){
        top = new FifoElement{objekt, nullptr};
        return *this;
    }else {
        FifoElement *zeiger = top;
        while (zeiger->next != nullptr) {
            zeiger = zeiger->next;
        }
        zeiger->next = new FifoElement{objekt, nullptr};
    }
    return *this;
}

Fifo& Fifo:: operator >> (string& objekt){
    if(top == nullptr){
        throw "ist leer";
    } else{
        groesse--;
        FifoElement *zeiger = top;
        objekt = top->value;
        top = top->next;
        delete zeiger;
    }
    return *this;
}

Fifo::~Fifo() {
    loeschen();
}

void Fifo::loeschen() {
    while (top != nullptr) {
        FifoElement* naestes = top->next;
        delete top;
        top = naestes;
    }
    groesse = 0;
}

Fifo:: operator size_t () const{

    return groesse;
}

Fifo::Fifo(const Fifo &original){
    top = nullptr;
    FifoElement *originalZeiger = original.top;
    for(size_t i = 0; i < original.groesse; i++){
        operator<<(originalZeiger->value);
        originalZeiger = originalZeiger->next;
    }
}

Fifo& Fifo:: operator = (const Fifo& fifo2){
    FifoElement *originalZeiger = fifo2.top;
    loeschen();
    for(size_t i = 0; i < fifo2.groesse; i++){
        operator<<(originalZeiger->value);
        originalZeiger = originalZeiger->next;
    }
    return *this;
}

void Fifo:: info(){

}