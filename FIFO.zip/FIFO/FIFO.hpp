#pragma once
#include <string>

using namespace std;

//Interne Klasse FifoElement; soll nicht extern benutzt werden
class FifoElement {
public:
    const string value;
    FifoElement *next;
    /*
    FifoElement(const string& value2, FifoElement* next){
        this->value = value2;
        this->next = next;
    }*/

};

//Fifo Klasse zur Implementation einer Warteschlange
class Fifo {
public:
    size_t groesse = 0;
    FifoElement *top;
    Fifo();
    ~Fifo();// = default;
    Fifo& operator << (const string& objekt);
    Fifo& operator >> (string& objekt);
    Fifo(const Fifo& original);
    operator size_t () const;
    Fifo& operator = (const Fifo& fifo2);
    void info();

    void loeschen();
};