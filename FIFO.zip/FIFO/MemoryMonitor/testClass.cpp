//#include "MemoryMonitor.hpp"
#include <iostream>

using namespace std;

int main()
{
    int *a = new int[10];
    int *b = new int;

    //memoryMonitor.printMemoryList();
    //memoryMonitor.printMemoryListArray();

    delete[] a;
    delete[] b;

	return 0;
}
