#include "gtest/gtest.h"
#include "../FIFO.hpp"
#include "../MemoryMonitor/MemoryMonitor.hpp"

TEST(FIFO, PushAndPopOneElement) {
    Fifo fifo;
    string res;

    fifo << "test";
    fifo >> res;

    ASSERT_EQ(res, "test");
}

TEST(FIFO, PushAndPopThreeElements) {
    Fifo fifo;
    string s1,s2,s3;

    fifo << "test1" << "test2" << "test3";
    fifo >> s1 >> s2 >> s3;

    ASSERT_EQ(s1, "test1");
    ASSERT_EQ(s2, "test2");
    ASSERT_EQ(s3, "test3");
}

TEST(FIFO, EmptyFifoSizeZero) {
    Fifo fifo;
    string str;

    //Ein neuer FIFO hat eine größe von 0
    ASSERT_EQ((size_t)fifo, 0);

    fifo << "a" << "b";
    fifo >> str >> str;

    //Ein komplett geleerter FIFO auch
    ASSERT_EQ((size_t)fifo, 0);
}

TEST(FIFO, CheckFifoSizeNonZero) {
    Fifo fifo;
    string str;

    fifo << "eins";
    ASSERT_EQ(size_t(fifo), 1);
    fifo << "eins" << "zwei";
    ASSERT_EQ(size_t(fifo), 3);
    fifo >> str >> str;
    ASSERT_EQ(size_t(fifo), 1);
    fifo >> str;
    ASSERT_EQ(size_t(fifo), 0);
}

TEST(FIFO, PopEmptyFifo) {
    Fifo fifo;
    string str;

    //Lesen aus einem leeren Fifo wirft eine Exception
    ASSERT_THROW(fifo >> str, const char*);

    fifo << "test";
    fifo >> str;

    //Lesen aus einem erneut leeren Fifo auch
    ASSERT_THROW(fifo >> str, const char*);
}

TEST(FIFO,CopyConstructor) {
    Fifo fifo;
    fifo << "eins" << "zwei" << "drei";

    //Eine Kopie erstellen über einen konstanten Fifo
    const Fifo& constFifo = fifo;
    Fifo kopie(constFifo);

    //Original Fifo leeren
    string str;
    fifo >> str >> str >> str;

    //Die Kopie hat immer noch 3 Elemente
    ASSERT_EQ((size_t)kopie, 3);

    //Beim Lesen aus der Kopie darf es keine Exception geben
    ASSERT_NO_THROW(kopie >> str);
    ASSERT_EQ(str,"eins");
    ASSERT_NO_THROW(kopie >> str);
    ASSERT_EQ(str,"zwei");
    ASSERT_NO_THROW(kopie >> str);
    ASSERT_EQ(str,"drei");
}

TEST(FIFO,AssignmentOperator) {
    Fifo fifo;
    fifo << "eins" << "zwei" << "drei";

    //Zuweisung über kostanten Fifo
    const Fifo& constFifo = fifo;
    Fifo kopie;

    //Kopie vorher mit Werten füllen. Diese müssen bei der Zuweisung entfernt werden.
    kopie << "Vier" << "Fünf" << "Sechs";
    ASSERT_NO_THROW(kopie = constFifo);

    //Original komplett leeren
    string str;
    ASSERT_NO_THROW(fifo >> str >> str >> str);

    //Die Kopie hat immer noch 3 Elemente
    ASSERT_EQ((size_t)kopie, 3);

    ASSERT_NO_THROW(kopie >> str);
    ASSERT_EQ(str,"eins");
    ASSERT_NO_THROW(kopie >> str);
    ASSERT_EQ(str,"zwei");
    ASSERT_NO_THROW(kopie >> str);
    ASSERT_EQ(str,"drei");
}

TEST(FIFO, CopyAndAssignmentSize) {
    Fifo fifo;
    string str;

    fifo << "eins" << "zwei" << "drei";

    Fifo kopie(fifo);
    ASSERT_EQ(size_t(kopie), 3);
    ASSERT_EQ(size_t(fifo), 3);

    fifo >> str >> str;
    ASSERT_EQ(size_t(kopie), 3);
    ASSERT_EQ(size_t(fifo), 1);

    kopie >> str >> str;
    ASSERT_EQ(size_t(kopie), 1);
    ASSERT_EQ(size_t(fifo), 1);

    fifo << "vier" << "fünf";
    kopie = fifo;
    ASSERT_EQ(size_t(kopie), 3);
    ASSERT_EQ(size_t(fifo), 3);

    fifo >> str >> str;
    ASSERT_EQ(size_t(kopie), 3);
    ASSERT_EQ(size_t(fifo), 1);

    kopie >> str >> str;
    ASSERT_EQ(size_t(kopie), 1);
    ASSERT_EQ(size_t(fifo), 1);
}

TEST(FIFO, CheckMemoryLeackagePushPop) {
    Fifo f;
    string str;

    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete(); //Abbruch bei falschem delete

    //Fifo füllen und wieder leeren
    f << "eins" << "zwei" << "drei";
    f >> str >> str >> str;

    //Es darf kein Speicher überbleiben
    ASSERT_EQ(snapshot->count(), 0);
    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(FIFO, CheckMemoryLeackageCopyConstructor) {
    Fifo f;
    f << "eins" << "zwei" << "drei";

    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete(); //Abbruch bei falschem delete

    //Kopie erstellen
    Fifo* kopie = new Fifo(f);
    delete kopie;

    //Es darf kein Speicher überbleiben
    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(FIFO, CheckMemoryLeackageAssignment) {
    Fifo fifo;
    Fifo* kopie = new Fifo;
    int mbiCount;

    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete(); //Abbruch bei falschem delete

    fifo << "eins" << "zwei" << "drei";
    mbiCount = snapshot->count();

    //Werte zuweisen
    *kopie = fifo;

    //Sollte gleich Anzahl an Speicher erzeugen
    ASSERT_EQ(snapshot->count(), mbiCount * 2);

    //Kopie löschen
    snapshot->unsetAbortOnWrongDelete();
    delete kopie;

    //Es darf kein Speicher überbleiben
    ASSERT_EQ(snapshot->count(), mbiCount);
    memoryMonitor.deleteSnapshot(snapshot);
}