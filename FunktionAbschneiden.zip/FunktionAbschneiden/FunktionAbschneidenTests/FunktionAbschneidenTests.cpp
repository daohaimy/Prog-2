#include <string>

#include "gtest/gtest.h"
#include "../abschneiden.h"

using namespace std;

TEST(ABSCHNEIDEN, RueckgabeUeberParameter) {
    float res = 1.23456;
    float x = res;

    //Da das Ergebnis wieder über x zurückgegeben wird, muss x einen anderen Wert haben
    //als vor dem Aufruf
    abschneiden(x, 1);
    ASSERT_NE(x, res);
}

/*
 * Benutzen Sie auch den Debugger um die folgenden Tests zu analysieren!
 * Warum schlagen mache Tests fehl, obwohl die Berechnung richtig zu sein scheint?
 */

TEST(ABSCHNEIDEN, AbschneidenWertEinfach) {
    float x = 1.123456;
    float y = 1.12;

    abschneiden(x,2);
    cout << x << endl;
    ASSERT_EQ(x, y);
}

TEST(ABSCHNEIDEN, AbschneidenWertMittel) {
    float x = 1.23456;
    float y = 1.23;

    //Welchen Wert hat x hier nach dem Abschneiden?
    //Können Sie daran etwas ändern?
    abschneiden(x,2);
    cout << x << endl;
    ASSERT_EQ(x, y);
}

TEST(ABSCHNEIDEN, AbschneidenWertSchwer) {
    float x = 1.345678;
    float y = 1.34;

    abschneiden(x,2);
    cout << x << endl;
    ASSERT_EQ(x, y);
}
