#include <iostream>
#include <iomanip>
using namespace std;

void abschneiden(float& x, int n) {
    if(0 < x < 1000 && 1 <= n <= 5) {
        for (int i = 0; i < n; i++) {
            x = x * 10;
        }
        int x2 = (int) x;
        float x4 = (float)x2;
        for (int i = 0; i < n; i++){
            x4 = x4 / 10.0;
        }
        x = x4;
    }

    //x soll vom Typ float sein und auch zur Rückgabe genutzt werden
    //n soll zwischen 1 und 5 sein
}