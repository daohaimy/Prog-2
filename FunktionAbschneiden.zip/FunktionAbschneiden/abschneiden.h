#pragma once

void abschneiden(float& x, int n);