#include "CSimpleCanvas.h"
#include <Windows.h>

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_PAINT:
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hwnd, msg, wParam, lParam);
}

void simpleCanvasWindow(CSimpleCanvas* simpleCanvas) {
    HINSTANCE hInstance;
    MSG msg;

    hInstance = GetModuleHandle(nullptr);

    WNDCLASS wc{ 0 };
    wc.style = CS_SAVEBITS;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "CSimpleCanvas";
    RegisterClass(&wc);

    {
        std::unique_lock<std::mutex> lk(simpleCanvas->mutex);

        simpleCanvas->windowHandle = CreateWindow("CSimpleCanvas",
            "CSimpleCanvas",
            WS_VISIBLE,
            100, 100,
            simpleCanvas->width, simpleCanvas->height,
            nullptr, nullptr, hInstance, nullptr);

        simpleCanvas->initialized = true;
        simpleCanvas->cv.notify_all();
    }

    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    {
        std::lock_guard<std::mutex> lk(simpleCanvas->mutex);
        DestroyWindow(simpleCanvas->windowHandle);
        simpleCanvas->windowHandle = nullptr;
    }

    UnregisterClass("CSimpleCanvas", hInstance);
}