#pragma once

#ifdef WIN32

#include <windows.h>
#include <iostream>
#include <algorithm>
#include <thread>
#include <mutex>
#include <condition_variable>

struct Pixel {
    unsigned char b{0};
    unsigned char g{0};
    unsigned char r{0};

private:
    unsigned char zero{0};
};

class CSimpleCanvas;
void simpleCanvasWindow(CSimpleCanvas* simpleCanvas);

class CSimpleCanvas {
private:
    unsigned int width;
    unsigned int height;
    Pixel* pixels = nullptr;

    std::thread windowThread;
    mutable std::mutex mutex;
    mutable std::condition_variable cv;
    bool initialized = false;
    HWND windowHandle = nullptr;

    LRESULT friend CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
    void friend simpleCanvasWindow(CSimpleCanvas* simpleCanvas);

public:

    CSimpleCanvas(unsigned int width, unsigned int height) : width(width), height(height) {
        pixels = new Pixel[width * height];
        clear();
        windowThread = std::thread(simpleCanvasWindow, this);
    }

    ~CSimpleCanvas() {
        {
            std::unique_lock<std::mutex> lk(mutex);
            cv.wait(lk, [&]{ return initialized; } );
            if (windowHandle != nullptr) SendMessage(windowHandle, WM_CLOSE, 0, 0);
        }

        windowThread.join();
        delete pixels;
    }

    unsigned int getWidth() const { return width;}
    unsigned int getHeight() const { return height;}

    Pixel& operator()(unsigned int x, unsigned int y) {
        return pixels[y * width + x];
    }

    const Pixel& operator()(unsigned int x, unsigned int y) const {
        return pixels[y * width + x];
    }

    void clear() {
        std::fill(pixels, pixels + width * height, Pixel{});
    }

    void draw() const {
        std::unique_lock<std::mutex> lk(mutex);
        cv.wait(lk, [&] { return initialized; });

        if (windowHandle != nullptr) {
            HDC hDC = GetWindowDC(windowHandle);
            HDC hBitmapDC = CreateCompatibleDC(hDC);
            HBITMAP hBitmap = CreateBitmap(width,height,4,8,(void*)pixels);
            HGDIOBJ hOldBitmap;

            hOldBitmap = SelectObject(hBitmapDC, hBitmap);
            BitBlt(hDC,0,0,width,height,hBitmapDC,0,0,SRCCOPY);
            SelectObject(hDC,hOldBitmap);

            DeleteDC(hBitmapDC);
            DeleteObject(hBitmap);
            ReleaseDC(windowHandle,hDC);
        }
    }

    bool isWindowOpen() const {
        std::unique_lock<std::mutex> lk(mutex);
        cv.wait(lk, [&] { return initialized; });
        return windowHandle != nullptr;
    }
};

#endif
