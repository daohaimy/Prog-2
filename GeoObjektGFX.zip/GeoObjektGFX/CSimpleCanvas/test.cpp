#include "CSimpleCanvas.h"

int main() {
    CSimpleCanvas canvas(500, 500);

    do {
        for (unsigned int x = 0; x < canvas.getWidth(); ++x) {
            for (unsigned int y = 0; y < canvas.getHeight(); ++y) {
                canvas(x, y).r++;
            }
        }

        canvas.draw();
    } while(canvas.isWindowOpen());

    return 0;
}