#ifdef unix
#include "CSimpleCanvas.h"

void EventLoop(Display* display, bool* isOpen) {
    XEvent xevent;

    while(true) {
        XNextEvent(display, &xevent);

        switch(xevent.type) {
            case ClientMessage:
                *isOpen = false;
                return;
        }
    }
}

CSimpleCanvas::CSimpleCanvas(unsigned int width, unsigned int height) : width(width),height(height) {
    display = XOpenDisplay(nullptr);
    screenNum = DefaultScreen(display);
    window = XCreateSimpleWindow(display, RootWindow(display, screenNum), 10, 10, width, height, 1,
                                 BlackPixel(display, screenNum), WhitePixel(display, screenNum));
    //XSelectInput(display, window, StructureNotifyMask);
    XMapWindow(display, window);

    pixels = new Pixel[width * height];
    image = XCreateImage(display,DefaultVisual(display,screenNum),DefaultDepth(display,screenNum)
            ,ZPixmap,0,(char*)pixels,width,height,32,0);

    wmDeleteWindow = XInternAtom(display, "WM_DELETE_WINDOW", 0);
    XSetWMProtocols(display, window, &wmDeleteWindow, 1);

    isOpen = true;
    eventLoopThread = std::thread(EventLoop, display, &isOpen);
}

CSimpleCanvas::~CSimpleCanvas() {
    XClientMessageEvent dummyEvent {};
    dummyEvent.type = ClientMessage;
    dummyEvent.window = window;
    dummyEvent.format = 32;
    XSendEvent(display, window, 0, 0, (XEvent*)&dummyEvent);
    XFlush(display);

    eventLoopThread.join();

    XUnmapWindow(display, window);
    XDestroyWindow(display, window);
    XCloseDisplay(display);

    delete pixels;
}

unsigned int CSimpleCanvas::getWidth() const {
    return width;
}

unsigned int CSimpleCanvas::getHeight() const {
    return height;
}

Pixel& CSimpleCanvas::operator()(unsigned int x, unsigned int y) {
    return pixels[y * width + x];
}

const Pixel& CSimpleCanvas::operator()(unsigned int x, unsigned int y) const {
    return pixels[y * width + x];
}

void CSimpleCanvas::clear() {
    std::fill(pixels, pixels + width * height, Pixel{});
}

void CSimpleCanvas::draw() {
    if(isOpen) {
        XPutImage(display, window, DefaultGC(display, screenNum), image, 0, 0, 0, 0, width, height);
    }
}

bool CSimpleCanvas::isWindowOpen() const {
    return isOpen;
}

#endif
