#pragma once

#ifdef unix

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <thread>

struct Pixel {
    unsigned char b{0};
    unsigned char g{0};
    unsigned char r{0};

private:
    unsigned char zero{0};
};

void EventLoop(Display* display, bool* isOpen);

class CSimpleCanvas {
private:
    unsigned int width;
    unsigned int height;
    Pixel* pixels;

    Display* display;
    int screenNum;
    Window window;
    Atom wmDeleteWindow;
    XImage* image;

    std::thread eventLoopThread;
    bool isOpen;

public:
    CSimpleCanvas(unsigned int width, unsigned int height);
    ~CSimpleCanvas();

    unsigned int getWidth() const;
    unsigned int getHeight() const;

    Pixel& operator()(unsigned int x, unsigned int y);
    const Pixel& operator()(unsigned int x, unsigned int y) const;

    void clear();
    void draw();
    bool isWindowOpen() const;
};

#endif