#include "GeoObjektGFX.h"
#include <cmath>
#include "Pinsel.h"
#include "OperandenPassenNicht.h"

using namespace std;


//Vorgegeben
void GeoObjektGFX::zeichne(CSimpleCanvas& canvas) {
    for(int x = 0; x < getBreite(); ++x) {
        for(int y = 0; y < getHoehe(); ++y) {
            if(istPositionInnerhalb(Position(x, y))) {
                this->pinsel->male(canvas, Position(x + pos.x, y + pos.y));
            }
        }
    }
}

bool GeoObjektGFX:: istPositionInnerhalb(const Position& p) const{
    if(this->pos.x < p.x && this->pos.y < p.y) {
        return true;
    }
    return false;
}

void GeoObjektGFX:: setPinsel(Pinsel* pinselNeu) {
    this->pinsel = pinselNeu;
}

Pinsel* GeoObjektGFX::getPinsel() const {
    return this->pinsel;
}

void GeoObjektGFX:: setPos(const Position& p){
    this->pos = p;
}

Position GeoObjektGFX:: getPos() const{
    return this->pos;
}

GeoObjektGFX::~GeoObjektGFX() {
    delete this->pinsel;
}
/*
GeoObjektGFX* GeoObjektGFX::clone() const{
    return new GeoObjektGFX(*this);
}*/

GeoObjektGFX& GeoObjektGFX::assign(const GeoObjektGFX &rhs) {
    delete this->pinsel;
    if(rhs.pinsel != nullptr){

        if(const PinselFarbe* pinselFarbe = dynamic_cast<const PinselFarbe*>(rhs.pinsel)){
            pinsel = new PinselFarbe(*pinselFarbe);
        }
        else if(const PinselFarbeTransparent* pinselFarbeTransparent = dynamic_cast<const PinselFarbeTransparent*>(rhs.pinsel)){
            pinsel = new PinselFarbeTransparent(*pinselFarbeTransparent);
        }
        else if(const PinselInverter* pinselInverter = dynamic_cast<const PinselInverter*>(rhs.pinsel)){
            pinsel = new PinselInverter(*pinselInverter);
        }
        else if(const PinselAddierer* pinselAddierer = dynamic_cast<const PinselAddierer*>(rhs.pinsel)){
            pinsel = new PinselAddierer(*pinselAddierer);
        }
    }
    else{
        pinsel = nullptr;
    }
    this->pos = rhs.pos;
    /*this->pos = rhs.pos;
    this->pinsel = rhs.pinsel;
    */
    return *this;
}

GeoObjektGFX::GeoObjektGFX(const GeoObjektGFX &geoObjektGfx) {
    if(geoObjektGfx.pinsel != nullptr){
        if(const PinselFarbe* pinselFarbe = dynamic_cast<const PinselFarbe*>(geoObjektGfx.pinsel)){
            pinsel = new PinselFarbe(*pinselFarbe);
        }
        else if(const PinselFarbeTransparent* pinselFarbeTransparent = dynamic_cast<const PinselFarbeTransparent*>(geoObjektGfx.pinsel)){
            pinsel = new PinselFarbeTransparent(*pinselFarbeTransparent);
        }
        else if(const PinselInverter* pinselInverter = dynamic_cast<const PinselInverter*>(geoObjektGfx.pinsel)){
            pinsel = new PinselInverter(*pinselInverter);
        }
        else if(const PinselAddierer* pinselAddierer = dynamic_cast<const PinselAddierer*>(geoObjektGfx.pinsel)){
            pinsel = new PinselAddierer(*pinselAddierer);
        }
    }
    else{
        pinsel = nullptr;
    }
    this->pos = geoObjektGfx.pos;
}

GeoObjektGFX &GeoObjektGFX::operator=(const GeoObjektGFX& geo) {
    if (this == &geo){
        return *this;
    }
    else if(typeid(*this) != typeid(geo)){
        throw OperandenPassenNicht();
    } else{
        return assign(geo);
    }
}


int Rechteck:: getBreite() const{
    return this->breite;
}

int Rechteck:: getHoehe() const{
    return this->hoehe;
}

bool Rechteck:: istPositionInnerhalb(const Position& p) const{
    if(this->hoehe < p.y && this->breite < p.x) {
        return true;
    }
    return false;
}



Rechteck* Rechteck::clone() const{
    return new Rechteck(*this);
}

Rechteck& Rechteck::operator=(const Rechteck& rechteck){
    if (this == &rechteck){
        return *this;
    }else if(typeid(*this) != typeid(rechteck)){
        throw OperandenPassenNicht();
    }
    else{
        return assign(rechteck);
    }
}


Rechteck& Rechteck::assign(const GeoObjektGFX &rhs) {
    const Rechteck* pU = dynamic_cast<const Rechteck*>(&rhs);
    if(!pU){
        return *this;
    }
    GeoObjektGFX::assign(rhs);
    this->breite = pU->breite;
    this->hoehe = pU->hoehe;
    return *this;
}


bool Kreis:: istPositionInnerhalb(const Position& p) const{
    /*
    double x_diff = p.x - this->radius;
    double y_diff = p.y - this->radius;

    double x_diffQuad = x_diff*x_diff;
    double y_diffQuad = y_diff*x_diff;

    double diff = x_diffQuad + y_diffQuad;

    double laenge = sqrt(diff);
     */

    if(this->radius < p.y && this->radius < p.x) {
        return true;
    }
    return false;
    /*if(laenge > this->radius) {
        return false;
    }
    return true;
     */
}

int Kreis:: getBreite() const{
    return 2*this->radius;
}
int Kreis:: getHoehe() const{
    return 2*this->radius;
}

Kreis* Kreis::clone() const{
    return new Kreis(*this);
}

Kreis& Kreis::operator=(const Kreis& kreis){
    if (this == &kreis) {
        return *this;
    }else if(typeid(*this) != typeid(kreis)){
        throw OperandenPassenNicht();
    }
    else {
        return assign(kreis);
    }
}

Kreis &Kreis::assign(const GeoObjektGFX &rhs) {
    const Kreis* pU = dynamic_cast<const Kreis*>(&rhs);
    if(!pU){
        return *this;
    }
    GeoObjektGFX::assign(rhs);
    this->radius = pU->radius;
    return *this;
}
/*
int Kreis::getRadius() const {
    return this->radius;
}*/
/*
Kreis &Kreis::operator=(const GeoObjektGFX &geoObjektGfx) {
    if (this == &geoObjektGfx) {
        throw OperandenPassenNicht();
    } else {
        throw OperandenPassenNicht();
    }
}*/

