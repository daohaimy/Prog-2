#pragma once
#include "CSimpleCanvas.h"
#include "Position.hpp"
#include "Pinsel.h"


class GeoObjektGFX{
    Pinsel* pinsel;
    Position pos;
protected:
    virtual bool istPositionInnerhalb(const Position& p) const = 0;
    GeoObjektGFX(Pinsel* pinsel, const Position& pos): pinsel(pinsel), pos(pos){};
    virtual GeoObjektGFX& assign(const GeoObjektGFX& rhs);

public:
    //GeoObjektGFX() = default; // Standardkonstruktor
    GeoObjektGFX(const GeoObjektGFX& geoObjektGfx);// Kopierkonstruktor
    GeoObjektGFX& operator = (const GeoObjektGFX& geo); // Zuweisungsoperator
    virtual ~GeoObjektGFX() = 0; // Destruktor

    void setPinsel(Pinsel* pinsel);
    Pinsel* getPinsel () const;
    void setPos(const Position& pos);
    Position getPos() const;
    void zeichne(CSimpleCanvas& canvas);
    virtual int getBreite() const = 0;
    virtual int getHoehe() const = 0;
    //virtual int getRadius() const = 0;

    virtual GeoObjektGFX* clone() const = 0;

};

class Rechteck: public GeoObjektGFX{
    int breite;
    int hoehe;
protected:
    bool istPositionInnerhalb(const Position& pos) const override;
    Rechteck& assign(const GeoObjektGFX& rhs) override;

public:
    Rechteck();
    Rechteck(const Position& pos, int breite, int hoehe, Pinsel* pinsel): GeoObjektGFX(pinsel, pos), breite(breite), hoehe(hoehe){};
    Rechteck(const Rechteck& rhs) = default;
    int getBreite() const override;
    int getHoehe() const override;

    ~Rechteck() override = default;

    Rechteck* clone() const override;
    Rechteck& operator = (const Rechteck& rechteck);
    //Rechteck& operator=(const GeoObjektGFX& geoObjektGfx);

};

class Kreis: public GeoObjektGFX{
    int radius;
protected:
    bool istPositionInnerhalb(const Position& pos) const override;
public:
    Kreis(const Position& pos, int radius, Pinsel* pinsel): GeoObjektGFX(pinsel, pos), radius(radius){};
    Kreis(const Kreis& rhs) = default;
    int getBreite() const override;
    int getHoehe() const override;
    //int getRadius(){};
    ~Kreis() override = default;

    Kreis* clone() const override;
    Kreis& operator=(const Kreis& kreis);
    //Kreis& operator=(const GeoObjektGFX& geoObjektGfx);
    Kreis& assign(const GeoObjektGFX& rhs) override;
};