#include <iostream>
#include <vector>
#include <chrono>
#include <thread>

#include "../GeoObjektGFX.h"

using namespace std;

struct Direction {
    int x;
    int y;
};

Pinsel* generateRandomBrush() {
    Pinsel* p;

    switch(rand() % 8) {
        case 0:
        case 1:
            p = new PinselFarbe(rand() % 255, rand() % 255, rand() % 255);
            break;
        case 2:
        case 3:
        case 6:
            p = new PinselFarbeTransparent(rand() % 255, rand() % 255, rand() % 255, rand() % 255);
            break;
        case 4:
        case 5:
            p = new PinselAddierer(rand() % 255, rand() % 255, rand() % 255);
            break;
        case 7:
        default:
            p = new PinselInverter();
            break;
    }

    return p;
}

GeoObjektGFX* generateRandomGeoObjekt() {
    switch(rand() % 2) {
        case 0:
            return new Rechteck(Position(rand() % 500,rand() % 500),rand() % 50 + 10, rand() % 50 + 10, nullptr);
        default:
            return new Kreis(Position(rand() % 500,rand() % 500),rand() % 50 + 10, nullptr);
    }
}

void moveAllObjects(const vector<GeoObjektGFX*>& geo, vector<Direction>& dir, int width, int height) {
    for(size_t i = 0; i < geo.size(); ++i) {
        //GeoObjekt bewegen
        geo[i]->setPos(Position{ geo[i]->getPos().x + dir[i].x, geo[i]->getPos().y + dir[i].y });

        //Richtung ändern
        if(geo[i]->getPos().x < 0) {
            geo[i]->setPos(Position{0, geo[i]->getPos().y});
            dir[i].x = abs(dir[i].x);
        }
        else if(geo[i]->getPos().x > width - geo[i]->getBreite()) {
            geo[i]->setPos(Position{width - geo[i]->getBreite(), geo[i]->getPos().y});
            dir[i].x = -1 * abs(dir[i].x);
        }

        if(geo[i]->getPos().y < 0) {
            geo[i]->setPos(Position{geo[i]->getPos().x, 0});
            dir[i].y = abs(dir[i].y);
        }
        else if(geo[i]->getPos().y > height - geo[i]->getHoehe()) {
            geo[i]->setPos(Position{geo[i]->getPos().x, height - geo[i]->getHoehe()});
            dir[i].y = -1 * abs(dir[i].y);
        }
    }
}

int main() {
    CSimpleCanvas canvas(1000,1000);

    vector<GeoObjektGFX*> geoObjekte;
    vector<Direction> directions;

    for(unsigned int i = 0; i < 100; ++i) {
        GeoObjektGFX* geo = generateRandomGeoObjekt();
        geo->setPinsel(generateRandomBrush());
        geoObjekte.push_back(geo);
        directions.push_back(Direction{rand() % 10 - 5,rand() % 10 - 5});
    }

    while (canvas.isWindowOpen()) {
        //Das Bild löschen (auf Schwarz setzen)
        canvas.clear();

        //Alle GeoObjekte zeichnen
        for(auto g : geoObjekte) {
            g->zeichne(canvas);
        }

        //Alle GeoObjekte bewegen
        moveAllObjects(geoObjekte, directions, 1000 , 1000);

        //Bild rendern
        canvas.draw();

        std::this_thread::sleep_for(chrono::milliseconds(10));
    }

    for(auto geo : geoObjekte) {
        delete geo;
    }

    return 0;
}
