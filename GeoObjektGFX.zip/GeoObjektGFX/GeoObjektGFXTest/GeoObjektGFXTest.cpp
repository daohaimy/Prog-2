#include "gtest/gtest.h"
#include "../GeoObjektGFX.h"
#include "../MemoryMonitor/MemoryMonitor.hpp"
#include "../OperandenPassenNicht.h"

TEST(Rechteck, BreiteUndHoeheNormal) {
    Rechteck r(Position(10,10), 12, 23, nullptr);

    //Breite und Hoehe können wieder gelesen werden, ganz einfach
    ASSERT_EQ(r.getBreite(), 12);
    ASSERT_EQ(r.getHoehe(), 23);
}

TEST(Rechteck, BreiteUndHoehePolymorph) {
    Rechteck r(Position(10,10), 12, 23, nullptr);

    const GeoObjektGFX &g = r;

    //Breite und Hoehe werden wieder gelesen. Dieses Mal über die konstante Basisklasse
    ASSERT_EQ(g.getBreite(), 12);
    ASSERT_EQ(g.getHoehe(), 23);
}

TEST(Rechteck, KopierKonstruktor) {
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete();

    //Einen Pinsel erstellen
    Pinsel *p = new PinselFarbe(1,2,3);

    //Rechteck erstellen und dann über Kopierkonstruktor kopieren
    const Rechteck* r = new Rechteck(Position(10,20), 12, 23, p);
    Rechteck* r2 = new Rechteck(*r);

    //Breite, Hoehe und Position muss gleich sein
    ASSERT_EQ(r2->getBreite(), 12);
    ASSERT_EQ(r2->getHoehe(), 23);
    ASSERT_EQ(r2->getPos().x, 10);
    ASSERT_EQ(r2->getPos().y, 20);

    //Es muss 4 Mal Speicher reserviert worden sein.
    //2 Mal für Rechteck und 2 Mal für die Pinsel in den Rechtecken (tiefe Kopie)
    ASSERT_EQ(snapshot->count(), 4);

    //Urpsrüngliches Rechteck löschen
    ASSERT_NO_THROW(delete r);

    //Danach gibt es noch 2 Speicherblöcke, neues Rechteck und tief kopierter Pinsel
    ASSERT_EQ(snapshot->count(), 2);

    //Und das gleiche nochmal für die Kopie
    ASSERT_NO_THROW(delete r2);
    ASSERT_EQ(snapshot->count(), 0);

    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(Rechteck, ZuweisungsOperatorNormal) {
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete();

    Rechteck r1(Position(11, 22), 10, 20, nullptr);
    const Rechteck r2(Position(33, 44), 30, 40, nullptr);

    //Keine Exception
    ASSERT_NO_THROW(r1 = r2);

    //Kein neuer Speicher
    ASSERT_EQ(snapshot->count(), 0);

    //Alle Werte gesetzt
    ASSERT_EQ(r1.getPos().x, 33);
    ASSERT_EQ(r1.getPos().y, 44);
    ASSERT_EQ(r1.getBreite(), 30);
    ASSERT_EQ(r1.getHoehe(), 40);

    //Mit Pinsel
    const Rechteck r3(Position(33, 44), 30, 40, new PinselFarbe(11,22,33));

    //Keine Exception
    ASSERT_NO_THROW(r1 = r3);

    //Speicher für einen Pinsel (und den ursprünglichen)
    ASSERT_EQ(snapshot->count(), 2);

    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(Rechteck, ZuweisungsOperatorPoly) {
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete();

    {
        Rechteck rOhnePinsel1(Position(11, 22), 10, 20, nullptr);
        Rechteck rOhnePinsel2(Position(33, 44), 30, 40, nullptr);
        Rechteck rMitPinsel1(Position(11, 22), 10, 20, new PinselFarbe(11, 22, 33));
        Rechteck rMitPinsel2(Position(33, 44), 30, 40, new PinselFarbe(44, 55, 66));

        const GeoObjektGFX &gOhnePinsel = rOhnePinsel1;
        const GeoObjektGFX &gMitPinsel = rMitPinsel1;

        GeoObjektGFX &gKopieOhnePinsel = rOhnePinsel2;
        GeoObjektGFX &gKopieMitPinsel = rMitPinsel2;

        //Beide Rechtecke werden über den Basisklassenzeiger zugewiesen
        ASSERT_NO_THROW(gKopieOhnePinsel = gOhnePinsel);
        ASSERT_NO_THROW(gKopieMitPinsel = gMitPinsel);

        //Die Kopie vergleichen mit dem Original - ohne Pinsel
        ASSERT_EQ(gKopieOhnePinsel.getPinsel(), nullptr);
        ASSERT_EQ(gKopieOhnePinsel.getPos().x, gOhnePinsel.getPos().x);
        ASSERT_EQ(gKopieOhnePinsel.getPos().y, gOhnePinsel.getPos().y);
        ASSERT_EQ(gKopieOhnePinsel.getBreite(), gOhnePinsel.getBreite());

        //Die Kopie vergleichen mit dem Original - mit Pinsel
        ASSERT_NE(gKopieMitPinsel.getPinsel(), nullptr);
        ASSERT_TRUE(typeid(gKopieMitPinsel.getPinsel()) == typeid(rMitPinsel1.getPinsel()));
        ASSERT_NE(gKopieMitPinsel.getPinsel(), rMitPinsel1.getPinsel());
    }

    //Kein Speicher darf übrig bleiben
    ASSERT_EQ(snapshot->count(), 0);

    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(Rechteck, ZuweisungsOperatorPolyFalscherOperand) {
    Rechteck r(Position{10,20}, 30,40,nullptr);
    Kreis k(Position{50,60}, 70, new PinselFarbe(11,22,33));

    GeoObjektGFX& gr = r;
    GeoObjektGFX& gk = k;

    //Muss eine Exception werfen
    ASSERT_THROW(gr = gk, OperandenPassenNicht);

    //Darf nicht verändert worden sein
    ASSERT_EQ(r.getPos().x, 10);
    ASSERT_EQ(r.getPos().y, 20);
    ASSERT_EQ(r.getBreite(), 30);
    ASSERT_EQ(r.getHoehe(), 40);
    ASSERT_EQ(r.getPinsel(), nullptr);
}

TEST(Rechteck, CloneMitUndOhnePinsel) {
    Rechteck rOhnePinsel(Position(11, 22), 10, 20, nullptr);
    Rechteck rMitPinsel(Position(11, 22), 10, 20, new PinselFarbe(11, 22, 33));

    const GeoObjektGFX& gOhnePinsel = rOhnePinsel;
    const GeoObjektGFX& gMitPinsel = rMitPinsel;

    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete();

    GeoObjektGFX* cloneOhnePinsel = nullptr;
    GeoObjektGFX* cloneMitPinsel = nullptr;

    //Beide Rechtecke werden über den Basisklassenzeiger gecloned
    ASSERT_NO_THROW(cloneOhnePinsel = gOhnePinsel.clone());
    ASSERT_NO_THROW(cloneMitPinsel = gMitPinsel.clone());

    //Die neuen GeoObjekte müssen vom Typ Rechteck sein
    ASSERT_TRUE(typeid(*cloneOhnePinsel) == typeid(rOhnePinsel));
    ASSERT_TRUE(typeid(*cloneMitPinsel) == typeid(rMitPinsel));

    //Der Clone muss auch nullptr als Pinsel haben
    ASSERT_EQ(cloneOhnePinsel->getPinsel(), nullptr);

    //Der Clone muss denselben Pinsel typ haben
    ASSERT_TRUE(typeid(rMitPinsel.getPinsel()) == typeid(cloneMitPinsel->getPinsel()));

    //Es muss ein neuer Pinsel sein, denn sonst ist es keine tiefe Kopie
    ASSERT_TRUE(rMitPinsel.getPinsel() != cloneMitPinsel->getPinsel());

    //Beide Clone löschen, darf keine Exception werfen
    ASSERT_NO_THROW(delete cloneOhnePinsel);
    ASSERT_NO_THROW(delete cloneMitPinsel);

    //Kein Speicher darf übrig bleiben
    ASSERT_EQ(snapshot->count(), 0);

    memoryMonitor.deleteSnapshot(snapshot);
}

//-----
//Kreis
//-----

TEST(Kreis, BreiteUndHoeheNormal) {
    Kreis r(Position(10,10), 12, nullptr);

    //Breite und Hoehe können wieder gelesen werden, ganz einfach
    ASSERT_EQ(r.getBreite(), 24);
    ASSERT_EQ(r.getHoehe(), 24);
}

TEST(Kreis, BreiteUndHoehePolymorph) {
    Kreis r(Position(10,10), 12, nullptr);

    const GeoObjektGFX &g = r;

    //Breite und Hoehe werden wieder gelesen. Dieses Mal über die konstante Basisklasse
    ASSERT_EQ(g.getBreite(), 24);
    ASSERT_EQ(g.getHoehe(), 24);
}

TEST(Kreis, KopierKonstruktor) {
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete();

    //Einen Pinsel erstellen
    Pinsel *p = new PinselFarbe(1,2,3);

    //Kreis erstellen und dann über Kopierkonstruktor kopieren
    Kreis* r = new Kreis(Position(10,20), 12, p);
    Kreis* r2 = new Kreis((const Kreis)(*r));

    //Breite, Hoehe und Position muss gleich sein
    ASSERT_EQ(r2->getBreite(), 24);
    ASSERT_EQ(r2->getHoehe(), 24);
    ASSERT_EQ(r2->getPos().x, 10);
    ASSERT_EQ(r2->getPos().y, 20);

    //Es muss 4 Mal Speicher reserviert worden sein.
    //2 Mal für Kreis und 2 Mal für die Pinsel in den Kreisen (tiefe Kopie)
    ASSERT_EQ(snapshot->count(), 4);

    //Urpsrüngliches Kreis löschen
    ASSERT_NO_THROW(delete r);

    //Danach gibt es noch 2 Speicherblöcke, neues Kreis und tief kopierter Pinsel
    ASSERT_EQ(snapshot->count(), 2);

    //Und das gleiche nochmal für die Kopie
    ASSERT_NO_THROW(delete r2);
    ASSERT_EQ(snapshot->count(), 0);

    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(Kreis, ZuweisungsOperatorNormal) {
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete();

    Kreis r1(Position(11, 22), 10, nullptr);
    const Kreis r2(Position(33, 44), 30, nullptr);

    //Keine Exception
    ASSERT_NO_THROW(r1 = r2);

    //Kein neuer Speicher
    ASSERT_EQ(snapshot->count(), 0);

    //Alle Werte gesetzt
    ASSERT_EQ(r1.getPos().x, 33);
    ASSERT_EQ(r1.getPos().y, 44);
    ASSERT_EQ(r1.getBreite(), 60);
    ASSERT_EQ(r1.getHoehe(), 60);

    //Mit Pinsel
    const Kreis r3(Position(33, 44), 30, new PinselFarbe(11,22,33));

    //Keine Exception
    ASSERT_NO_THROW(r1 = r3);

    //Speicher für einen Pinsel (und den ursprünglichen)
    ASSERT_EQ(snapshot->count(), 2);

    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(Kreis, ZuweisungsOperatorPoly) {
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete();

    {
        Kreis rOhnePinsel1(Position(11, 22), 10, nullptr);
        Kreis rOhnePinsel2(Position(11, 22), 10, nullptr);
        Kreis rMitPinsel1(Position(11, 22), 10, new PinselFarbe(11, 22, 33));
        Kreis rMitPinsel2(Position(11, 22), 10, new PinselFarbe(11, 22, 33));

        const GeoObjektGFX &gOhnePinsel = rOhnePinsel1;
        const GeoObjektGFX &gMitPinsel = rMitPinsel1;

        GeoObjektGFX &gKopieOhnePinsel = rOhnePinsel2;
        GeoObjektGFX &gKopieMitPinsel = rMitPinsel2;

        //Beide Kreise werden über den Basisklassenzeiger zugewiesen
        ASSERT_NO_THROW(gKopieOhnePinsel = gOhnePinsel);
        ASSERT_NO_THROW(gKopieMitPinsel = gMitPinsel);

        //Die neuen GeoObjekte müssen vom Typ Kreis sein
        ASSERT_TRUE(typeid(gKopieOhnePinsel) == typeid(rOhnePinsel1));
        ASSERT_TRUE(typeid(gKopieMitPinsel) == typeid(rMitPinsel1));

        //Der Clone muss auch nullptr als Pinsel haben
        ASSERT_EQ(gKopieOhnePinsel.getPinsel(), nullptr);

        //Der Clone muss einen neuen Pinsel vom selben Typ haben
        ASSERT_NE(gKopieMitPinsel.getPinsel(), nullptr);
        ASSERT_TRUE(typeid(gKopieMitPinsel.getPinsel()) == typeid(rMitPinsel1.getPinsel()));
        ASSERT_NE(gKopieMitPinsel.getPinsel(), rMitPinsel1.getPinsel());
    }

    //Kein Speicher darf übrig bleiben
    ASSERT_EQ(snapshot->count(), 0);

    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(Kreis, ZuweisungsOperatorPolyFalscherOperand) {
    Kreis k(Position{50,60}, 70, nullptr);
    Rechteck r(Position{10,20}, 30,40,new PinselFarbe(11,22,33));

    GeoObjektGFX& gk = k;
    GeoObjektGFX& gr = r;

    //Muss eine Exception werfen
    ASSERT_THROW(gk = gr, OperandenPassenNicht);

    //Darf nicht verändert worden sein
    ASSERT_EQ(k.getPos().x, 50);
    ASSERT_EQ(k.getPos().y, 60);
    ASSERT_EQ(k.getBreite(), 140);
    ASSERT_EQ(k.getHoehe(), 140);
    ASSERT_EQ(k.getPinsel(), nullptr);
}

TEST(Kreis, CloneMitUndOhnePinsel) {
    Kreis rOhnePinsel(Position(11, 22), 10, nullptr);
    Kreis rMitPinsel(Position(11, 22), 10, new PinselFarbe(11, 22, 33));

    const GeoObjektGFX& gOhnePinsel = rOhnePinsel;
    const GeoObjektGFX& gMitPinsel = rMitPinsel;

    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();
    snapshot->setAbortOnWrongDelete();

    GeoObjektGFX* cloneOhnePinsel = nullptr;
    GeoObjektGFX* cloneMitPinsel = nullptr;

    //Beide Kreise werden über den Basisklassenzeiger gecloned
    ASSERT_NO_THROW(cloneOhnePinsel = gOhnePinsel.clone());
    ASSERT_NO_THROW(cloneMitPinsel = gMitPinsel.clone());

    //Die neuen GeoObjekte müssen vom Typ Kreis sein
    ASSERT_TRUE(typeid(*cloneOhnePinsel) == typeid(rOhnePinsel));
    ASSERT_TRUE(typeid(*cloneMitPinsel) == typeid(rMitPinsel));

    //Der Clone muss auch nullptr als Pinsel haben
    ASSERT_EQ(cloneOhnePinsel->getPinsel(), nullptr);

    //Der Clone muss denselben Pinsel typ haben
    ASSERT_TRUE(typeid(rMitPinsel.getPinsel()) == typeid(cloneMitPinsel->getPinsel()));

    //Es muss ein neuer Pinsel sein, denn sonst ist es keine tiefe Kopie
    ASSERT_TRUE(rMitPinsel.getPinsel() != cloneMitPinsel->getPinsel());

    //Beide Clone löschen, darf keine Exception werfen
    ASSERT_NO_THROW(delete cloneOhnePinsel);
    ASSERT_NO_THROW(delete cloneMitPinsel);

    //Kein Speicher darf übrig bleiben
    ASSERT_EQ(snapshot->count(), 0);

    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(Pinsel, PinselFarbeClone) {
    PinselFarbe f(1,2,3);
    PinselFarbe* clone = f.clone();
    Pinsel* cloneBase = clone->clone();
    ASSERT_TRUE(typeid(f) == typeid(*cloneBase));
    delete clone;
    delete cloneBase;
}

TEST(Pinsel, PinselFarbeTransparentClone) {
    PinselFarbeTransparent f(1,2,3, 0.5);
    PinselFarbeTransparent* clone = f.clone();
    Pinsel* cloneBase = clone->clone();
    ASSERT_TRUE(typeid(f) == typeid(*cloneBase));
    delete clone;
    delete cloneBase;
}

TEST(Pinsel, PinselAddiererClone) {
    PinselAddierer f(1,2,3);
    PinselAddierer* clone = f.clone();
    Pinsel* cloneBase = clone->clone();
    ASSERT_TRUE(typeid(f) == typeid(*cloneBase));
    delete clone;
    delete cloneBase;
}

TEST(Pinsel, PinselInverterClone) {
    PinselInverter f;
    PinselInverter* clone = f.clone();
    Pinsel* cloneBase = clone->clone();
    ASSERT_TRUE(typeid(f) == typeid(*cloneBase));
    delete clone;
    delete cloneBase;
}

TEST(Rechteck, ZuweisungsOperatorFalscheOperanden) {
    Rechteck r(Position(11, 22), 10, 20, nullptr);
    Kreis k(Position(10,20), 12, nullptr);

    GeoObjektGFX& g1 = r;
    GeoObjektGFX& g2 = k;

    ASSERT_THROW(g1 = g2, OperandenPassenNicht);
}

TEST(Kreis, ZuweisungsOperatorFalscheOperanden) {
    Rechteck r(Position(11, 22), 10, 20, nullptr);
    Kreis k(Position(10,20), 12, nullptr);

    GeoObjektGFX& g1 = r;
    GeoObjektGFX& g2 = k;

    ASSERT_THROW(g2 = g1, OperandenPassenNicht);
}

TEST(Optional, SlicingVerhindert) {
    class Test : public Rechteck { public: Test() : Rechteck(Position{0,0}, 10, 10, nullptr) {} };

    Rechteck r(Position{10,10}, 20,30,new PinselFarbe(11,22,33));
    Test t;

    //Muss eine Exception werfen, weil nicht der gleiche Typ
    ASSERT_THROW(r = t, OperandenPassenNicht);

    //Rechteck r darf in keiner Weise verändert worden sein
    ASSERT_EQ(r.getPos().x, 10);
    ASSERT_EQ(r.getPos().y, 10);
    ASSERT_EQ(r.getBreite(), 20);
    ASSERT_EQ(r.getHoehe(), 30);
    ASSERT_NE(r.getPinsel(), nullptr);
}