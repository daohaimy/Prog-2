﻿#include <iostream>
#include <iomanip>
#include <algorithm>

#include "MemoryMonitor.hpp"

MemoryMonitor memoryMonitor;

void* operator new(size_t n)
{
    return memoryMonitor.mem_new(n, false);
}

void* operator new[](size_t n)
{
    return memoryMonitor.mem_new(n, true);
}

void operator delete(void* p) noexcept
{
    memoryMonitor.mem_del(p, false);
}

void operator delete[](void* p) noexcept
{
    memoryMonitor.mem_del(p, true);
}

void operator delete(void* p, size_t s) noexcept
{
    (void)s;
    memoryMonitor.mem_del(p, false);
}

void operator delete[](void* p, size_t s) noexcept
{
    (void)s;
    memoryMonitor.mem_del(p, true);
}

using namespace std;

void* MemoryMonitor::mem_new(size_t size, bool isArray) {
    char* mem = (char*)malloc(size);

    if(!mem) {
        throw std::bad_alloc();
    }
    else {
        if(enabled) {
            disable();
            postNewMemoryBlockInfoToSnapshots(MemoryBlockInfo(mem, size, isArray));
            enable();
        }
        std::fill(mem, mem + size, 0x42);
        return mem;
    }
}

void MemoryMonitor::mem_del(void *address, bool isArray) {
    bool oldState = enabled;

    if(enabled) {
        disable();
        postDeleteMemoryBlockInfoToSnapshots(address, isArray);
        if (oldState) enable();
    }

    free(address);
}

MemorySnapshot *MemoryMonitor::createSnapshot() {
    bool oldState = enabled;
    disable();

    auto* snap = new MemorySnapshot();
    snapshots.insert(snap);

    if(oldState) enable();
    return snap;
}

void MemoryMonitor::deleteSnapshot(MemorySnapshot *snapshot) {
    snapshots.erase(snapshot);
    delete snapshot;
}

void MemoryMonitor::postNewMemoryBlockInfoToSnapshots(MemoryBlockInfo mbi) {
    for(auto snap : snapshots) {
        snap->addMemoryBlockInfo(mbi);
    }
}

void MemoryMonitor::postDeleteMemoryBlockInfoToSnapshots(void *address, bool isArray) {
    for(auto snap : snapshots) {
        snap->removeMemoryBlockInfo(address, isArray);
    }
}

const MemoryBlockInfo &MemorySnapshot::operator[](void* address) {
    return memoryList[address];
}

void MemorySnapshot::printSummary() {
    cout << "List of allocated memory:" << endl;

    for(const auto& e : memoryList) {
        cout << setw(8) << setfill('0') << hex << e.second.getAddress() << "[" << e.second.getSize() << "]" << endl;
    }
}

void MemorySnapshot::addMemoryBlockInfo(const MemoryBlockInfo &mbi) {
    memoryList[mbi.getAddress()] = mbi;
}

void MemorySnapshot::removeMemoryBlockInfo(void* address, bool isArray) {
    if(abortOnWrongDelete) {
        if(memoryList.count(address) == 0) {
            //Speicher wurde nicht innerhalb der Snapshot-Lebensdauer erstellt!
            //abort();
            throw memoryblock_not_found{};
        }

        if(memoryList[address].isArray() != isArray) {
            //Falscher delete-Operator wurde benutzt!
            //abort();
            throw memoryblock_wrong_delete{};
        }
    }

    memoryList.erase(address);
}
