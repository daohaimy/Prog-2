﻿#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>

//Override global new and delete operators
#ifndef MEMORY_MONITOR_DISABLE
//extern void* operator new(size_t n);
//extern void* operator new[](size_t n);
//extern void operator delete(void* p) noexcept;
//extern void operator delete[](void* p) noexcept;
//extern void operator delete(void* p, size_t s) noexcept;
//extern void operator delete[](void* p, size_t s) noexcept;
#endif

struct memoryblock_not_found : std::exception {};
struct memoryblock_wrong_delete : std::exception {};

class MemoryBlockInfo {
public:
	MemoryBlockInfo() : address(nullptr), size(0), array(false) {}
    MemoryBlockInfo(const MemoryBlockInfo& rhs) = default;
	MemoryBlockInfo(void* address, size_t size, bool isArray) : address(address), size(size), array(isArray) {}
    MemoryBlockInfo& operator=(const MemoryBlockInfo&) = default;

	void* getAddress() const { return address; }
	size_t getSize() const { return size; }
    bool isArray() const { return array; }

private:
	void* address;
	size_t size;
    bool array;
};

class MemorySnapshot {
    friend class MemoryMonitor;

public:
    MemorySnapshot(const MemorySnapshot&) = delete;
    MemorySnapshot& operator=(const MemorySnapshot&) = delete;

    const MemoryBlockInfo& operator[](void*);
    size_t count() { return memoryList.size(); }

    void printSummary();
    void setAbortOnWrongDelete() { this->abortOnWrongDelete = true; }
    void unsetAbortOnWrongDelete() { this->abortOnWrongDelete = false; }

private:
    MemorySnapshot() : abortOnWrongDelete(false) {}
    void operator delete(void*) {}
    void addMemoryBlockInfo(const MemoryBlockInfo&);
    void removeMemoryBlockInfo(void* address, bool isArray);

    std::unordered_map<void*,MemoryBlockInfo> memoryList;
    bool abortOnWrongDelete;
};

class MemoryMonitor {
public:
	MemoryMonitor() : enabled(true) {}
    ~MemoryMonitor() = default;

    void* mem_new(size_t size, bool isArray);
    void mem_del(void* address, bool isArray);

    MemorySnapshot* createSnapshot();
    void deleteSnapshot(MemorySnapshot*);

    void enable() { enabled = true; }
    void disable() { enabled = false; }

private:
    void postNewMemoryBlockInfoToSnapshots(MemoryBlockInfo);
    void postDeleteMemoryBlockInfoToSnapshots(void* address, bool isArray);

    std::unordered_set<MemorySnapshot*> snapshots;
    bool enabled;
};

extern MemoryMonitor memoryMonitor;