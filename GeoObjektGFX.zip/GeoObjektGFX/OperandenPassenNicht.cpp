//
// Created by haimydao on 6/7/2023.
//

#include "OperandenPassenNicht.h"

/*
const char *OperandenPassenNicht::what() const noexcept {
    return "passt nicht";
}*/
