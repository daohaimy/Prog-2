//
// Created by haimydao on 6/7/2023.
//

#ifndef GEOOBJEKTGFX_OPERANDENPASSENNICHT_H
#define GEOOBJEKTGFX_OPERANDENPASSENNICHT_H
#include "exception"
#include <iostream>

class OperandenPassenNicht/*: public std::exception*/{
public:
    //const char* what() const noexcept override;
};


#endif //GEOOBJEKTGFX_OPERANDENPASSENNICHT_H
