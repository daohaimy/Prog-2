#include "Pinsel.h"
#include "Position.hpp"
using namespace std;

void PinselFarbe::male(CSimpleCanvas &canvas, const Position& pos) const {
    canvas(pos.x, pos.y).r = this->r; //Rotanteil (0 - 255) an pos x und y
    canvas(pos.x, pos.y).g = this->g; //Gr¨unanteil (0 - 255) an pos x und y
    canvas(pos.x, pos.y).b = this->b; //Blauanteil (0 - 255) an pos x und y
}

void PinselFarbeTransparent::male(CSimpleCanvas &canvas, const Position& pos) const {
    canvas(pos.x, pos.y).r = this->r;
    canvas(pos.x, pos.y).g = this->g;
    canvas(pos.x, pos.y).b = this->b;
}


void PinselInverter::male(CSimpleCanvas &canvas, const Position& pos) const {
    canvas(pos.x, pos.y).r = 255 - canvas(pos.x, pos.y).r; //Rotanteil (0 - 255) an pos x und y
    canvas(pos.x, pos.y).g = 255 - canvas(pos.x, pos.y).g; //Gr¨unanteil (0 - 255) an pos x und y
    canvas(pos.x, pos.y).b = 255 - canvas(pos.x, pos.y).b; //Blauanteil (0 - 255) an pos x und y
}

void PinselAddierer::male(CSimpleCanvas &canvas, const Position& pos) const {
    canvas(pos.x, pos.y).r += this->r;
    canvas(pos.x, pos.y).g += this->g;
    canvas(pos.x, pos.y).b += this->b;
}

PinselFarbe* PinselFarbe::clone() {
    return new PinselFarbe(*this);
}

PinselFarbeTransparent* PinselFarbeTransparent::clone() {
    return new PinselFarbeTransparent(*this);
}

PinselInverter* PinselInverter::clone() {
    return new PinselInverter(*this);
}

PinselAddierer* PinselAddierer::clone() {
    return new PinselAddierer(*this);;
}

