#pragma once

#include "CSimpleCanvas.h"
#include "Position.hpp"

class Pinsel {
public:
    virtual ~Pinsel() = default;
    virtual void male (CSimpleCanvas& canvas, const Position& p) const = 0;
    //virtual Pinsel* clone() const = 0;
};

class PinselFarbe: public Pinsel {
protected:
    unsigned char r;
    unsigned char g;
    unsigned char b;
public:
    PinselFarbe(unsigned char r, unsigned char g, unsigned char b):r(r), g(g), b(b){}
    void male(CSimpleCanvas& canvas, const Position& p) const override;
    PinselFarbe* clone();
};

class PinselFarbeTransparent: public PinselFarbe {
    double t;
public:
    PinselFarbeTransparent(unsigned char r, unsigned char g, unsigned char b, double t): PinselFarbe(r,g,b), t(t){};
    void male(CSimpleCanvas& canvas, const Position& p) const override;
    PinselFarbeTransparent* clone();
};

class PinselInverter: public Pinsel{
public:
    PinselInverter() = default;
    void male(CSimpleCanvas& canvas, const Position& p) const override;
    PinselInverter* clone();
};

class PinselAddierer: public PinselFarbe {
public:
    PinselAddierer(unsigned char r, unsigned char g, unsigned char b): PinselFarbe(r,g,b){}
    void male(CSimpleCanvas& canvas, const Position& p) const override;
    PinselAddierer* clone();
};
