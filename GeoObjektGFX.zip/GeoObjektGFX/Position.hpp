#pragma once

class Position{
public:
    int x;
    int y;
    Position(int x, int y): x(x), y(y){};
    Position() = default;
};