#include <iostream>
#include "PointerMitStrings.h"
#include "iterator"
#include "string"
using namespace std;


const char* sucheWortAnfang(const char* satz) {
    if(satz == nullptr ){
        return nullptr;
    }
    while(*satz != '\0'){
        if(*satz != ' '){
            return satz;
        }
        satz++;
    }
    return satz;
}

const char* sucheWortEnde(const char* satz) {
    if(satz == nullptr){
        return nullptr;
    }
    while(*satz != '\0'){
        if(*satz == ' ' || *satz == '\0'){
            return satz;
        }
        satz++;
    }
    return satz;
}

int zaehleWorte(const char* satz) {
    if(satz == nullptr){
        return 0;
    }
    int counter = 0;
    while(*satz != '\0'){
        if(*satz != '\0' && *satz != ' '){
            while(*satz != ' ' && *satz != '\0'){
                satz++;
            }
            counter++;
        }
        satz++;
    }
    return counter;
}

char** erstelleWortFeld(const char* satz) {
    if(satz == nullptr){
        return nullptr;
    }
    int counter = 0;

    char** array = new char*[zaehleWorte(satz)];

    while(*satz != '\0'){
        if(*satz != ' ') {

        }
        satz++;
    }
    array[zaehleWorte(satz)];
    return array;
}

char* loescheFeld(char** satz) {
    if(*satz == nullptr){
        return nullptr;
    }
    int counter = 0;
    char** array = new char*[zaehleWorte(*satz)];
    while(**satz != '\0'){
        if(**satz != ' ') {

        }
        satz++;
    }
    array[zaehleWorte(*satz)];
    return *array;
    /*char** array = reinterpret_cast<char **>(new char[zaehleWorte(*satz)]);
    if(*satz == nullptr){
        return nullptr;
    }
    int counter = 0;

    while(**satz != '\0'){
        if(**satz != ' ') {
            while (**satz != ' ') {
                *array[counter] = **satz;
            }
            counter++;
        }
        satz++;
    }

    erstelleWortFeld(*satz);
    if(satz == nullptr){
        return nullptr;
    }
    for(int i = 0; i < zaehleWorte(*satz); i++){
        if(array[i] == *satz){
            array[i] = nullptr;
        }
    }
    return *array;*/
}

char* feldAusgeben(char** satz) {
    char** array = reinterpret_cast<char **>(new char[zaehleWorte(*satz)]);
    if(satz == nullptr){
        return nullptr;
    }
    int counter = 0;

    while(**satz != '\0'){
        if(**satz != ' ') {

        }
        satz++;
    }
    array[zaehleWorte(*satz)];
    return *array;
    /*
    while(**satz != '\0'){
        if(**satz != ' ') {
            while (**satz != ' ') {
                **feld[counter] = **satz;
            }
            feld[counter] = feld[counter] + '\0';
            counter++;
        }
    }
    *feld[counter++] = nullptr;*/
    /*
    for(int i = 0; i < zaehleWorte(*satz); i++){
        cout << to_string(*array[i]) << endl;
    }*/
    return nullptr;
}

char* tauscheWorte(char* wort1, char* wort2) {
    if(wort1 == nullptr && wort2 == nullptr){
        return nullptr;
    }
    char* wort3 = wort1;
    *wort1 = *wort2;
    *wort2 = *wort3;
    return nullptr;
}

//Die main() ist in pointermitstringstests/PointerMitStringsSpielerei.cpp