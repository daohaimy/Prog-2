#pragma once
#include <string>
#include "iostream"
using namespace std;

const char* sucheWortAnfang(const char* satz);
const char* sucheWortEnde(const char* satz);
int zaehleWorte(const char* satz);
char** erstelleWortFeld(const char* satz);
char* loescheFeld(char** satz);
char* feldAusgeben(char** satz);
char* tauscheWorte(char* wort1, char* wort2);
