#include "../PointerMitStrings.h"

int main() {
    char satz[] = "  Dies ist    ein String!  ";
    char** feld = erstelleWortFeld(satz);

    feldAusgeben(feld);

    tauscheWorte(feld[0], feld[2]);
    tauscheWorte(feld[1], feld[3]);

    feldAusgeben(feld);
    loescheFeld(feld);
}
