#include "gtest/gtest.h"
#include "../MemoryMonitor/MemoryMonitor.hpp"
#include "../PointerMitStrings.h"

const char STRING_EMPTY[] = "";
const char STRING_SPACE[] = "     ";
const char STRING_WORD_SPACE[] = "Wort   ";
const char STRING_SPACE_WORD[] = "   Wort";
const char STRING_ALL[] = "  Dies ist ein Test!  ";
const char* FELD_CHECK[] = { "Dies", "ist", "ein", "Test!", nullptr };

/*
 * sucheWortAnfang
 */

TEST(sucheWortAnfang, nullptr) {
    ASSERT_NO_THROW(sucheWortAnfang(nullptr));
    ASSERT_EQ(sucheWortAnfang(nullptr), nullptr);
}

TEST(sucheWortAnfang, empty) {
    ASSERT_NO_THROW(sucheWortAnfang(STRING_EMPTY));
    ASSERT_EQ(sucheWortAnfang(STRING_EMPTY), STRING_EMPTY);
}

TEST(sucheWortAnfang, space) {
    ASSERT_NO_THROW(sucheWortAnfang(STRING_SPACE));
    ASSERT_EQ(sucheWortAnfang(STRING_SPACE), STRING_SPACE + sizeof(STRING_SPACE) - 1);
}

TEST(sucheWortAnfang, wort_space) {
    ASSERT_NO_THROW(sucheWortAnfang(STRING_WORD_SPACE));
    ASSERT_EQ(sucheWortAnfang(STRING_WORD_SPACE), STRING_WORD_SPACE);
}

TEST(sucheWortAnfang, space_wort) {
    ASSERT_NO_THROW(sucheWortAnfang(STRING_SPACE_WORD));
    ASSERT_EQ(sucheWortAnfang(STRING_SPACE_WORD), STRING_SPACE_WORD + 3);
}

TEST(sucheWortAnfang, all) {
    ASSERT_NO_THROW(sucheWortAnfang(STRING_ALL));
    ASSERT_EQ(sucheWortAnfang(STRING_ALL), STRING_ALL + 2);
}

/*
 * sucheWortEnde
 */

TEST(sucheWortEnde, nullptr) {
    ASSERT_NO_THROW(sucheWortEnde(nullptr));
    ASSERT_EQ(sucheWortEnde(nullptr), nullptr);
}

TEST(sucheWortEnde, empty) {
    ASSERT_NO_THROW(sucheWortEnde(STRING_EMPTY));
    ASSERT_EQ(sucheWortEnde(STRING_EMPTY), STRING_EMPTY);
}

TEST(sucheWortEnde, space) {
    ASSERT_NO_THROW(sucheWortEnde(STRING_SPACE));
    ASSERT_EQ(sucheWortEnde(STRING_SPACE), STRING_SPACE);
}

TEST(sucheWortEnde, wort_space) {
    ASSERT_NO_THROW(sucheWortEnde(STRING_WORD_SPACE));
    ASSERT_EQ(sucheWortEnde(STRING_WORD_SPACE), STRING_WORD_SPACE + 4);
}

TEST(sucheWortEnde, space_wort) {
    ASSERT_NO_THROW(sucheWortEnde(STRING_SPACE_WORD + 3));
    ASSERT_EQ(sucheWortEnde(STRING_SPACE_WORD + 3), STRING_SPACE_WORD + 3 + 4);
}

TEST(sucheWortEnde, all) {
    //Für erstes Wort
    ASSERT_NO_THROW(sucheWortEnde(STRING_ALL + 2));
    ASSERT_EQ(sucheWortEnde(STRING_ALL + 2), STRING_ALL + 2 + 4);

    //Für letztes Wort
    ASSERT_NO_THROW(sucheWortEnde(STRING_ALL + 15));
    ASSERT_EQ(sucheWortEnde(STRING_ALL + 15), STRING_ALL + 15 + 5);
}

/*
 * zaehleWorte
 */

TEST(zaehleWorte, nullptr) {
    ASSERT_NO_THROW(zaehleWorte(nullptr));
}

TEST(zaehleWorte, empty) {
    ASSERT_NO_THROW(zaehleWorte(STRING_EMPTY));
    ASSERT_EQ(zaehleWorte(STRING_EMPTY), 0);
}

TEST(zaehleWorte, space) {
    ASSERT_NO_THROW(zaehleWorte(STRING_SPACE));
    ASSERT_EQ(zaehleWorte(STRING_SPACE), 0);
}

TEST(zaehleWorte, space_word) {
    ASSERT_NO_THROW(zaehleWorte(STRING_SPACE_WORD));
    ASSERT_EQ(zaehleWorte(STRING_SPACE_WORD), 1);
}

TEST(zaehleWorte, word_space) {
    ASSERT_NO_THROW(zaehleWorte(STRING_WORD_SPACE));
    ASSERT_EQ(zaehleWorte(STRING_WORD_SPACE), 1);
}

TEST(zaehleWorte, all) {
    ASSERT_NO_THROW(zaehleWorte(STRING_ALL));
    ASSERT_EQ(zaehleWorte(STRING_ALL), 4);
}

/*
 * erstelleWortFeld
 */

TEST(erstelleWortFeld, nullptr) {
    char** feld;

    //Speicherüberwachung starten
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();

    //Darf keine Exception werfen
    ASSERT_NO_THROW(feld = erstelleWortFeld(nullptr));

    //Muss nullptr zurückgeben
    ASSERT_EQ(feld, nullptr);

    //Kein Speicher darf reserviert worden sein
    ASSERT_EQ(snapshot->count(), 0);

    //Überwachung beenden
    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(erstelleWortFeld, space) {
    char** feld;

    //Speicherüberwachung starten
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();

    //Darf keine Exception werfen.
    ASSERT_NO_THROW(feld = erstelleWortFeld(STRING_SPACE));

    //Gibt einen Zeiger auf ein Feld zurück
    ASSERT_NE(feld, nullptr);

    //Es muss einmal Speichern reserviert worden sein
    ASSERT_EQ(snapshot->count(), 1);

    //Mit einer Länge von einem char* Zeiger
    ASSERT_EQ((*snapshot)[feld].getSize(), 1 * sizeof(char*));

    //Und es muss sich um ein Array handeln
    ASSERT_TRUE((*snapshot)[feld].isArray());

    //Dieses Feld enthält lediglich den nullptr an Stelle 0
    ASSERT_EQ(feld[0], nullptr);

    //Überwachung beenden
    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(erstelleWortFeld, word_space) {
    char** feld;

    //Speicherüberwachung starten
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();

    //Darf keine Exception werfen.
    ASSERT_NO_THROW(feld = erstelleWortFeld(STRING_WORD_SPACE));

    //Gibt einen Zeiger auf ein Feld zurück
    ASSERT_NE(feld, nullptr);

    //Es muss zweimal Speichern reserviert worden sein
    //Einmal für das Feld und einmal für das eine vorhandene Wort
    ASSERT_EQ(snapshot->count(), 2);

    //Das Feld hat 2 Einträge
    ASSERT_EQ((*snapshot)[feld].getSize(), 2 * sizeof(char*));

    //Das Wort hat eine Länge von 4 + 1 für '\0'
    ASSERT_EQ((*snapshot)[feld[0]].getSize(), 5 * sizeof(char));

    //Und es muss sich um Arrays handeln
    ASSERT_TRUE((*snapshot)[feld].isArray());
    ASSERT_TRUE((*snapshot)[feld[0]].isArray());

    //Das Feld enthält einen Zeiger auf den String "Wort" an Stelle 0
    ASSERT_STREQ(feld[0],"Wort");

    //...und and er Stelle 1 den nullptr
    ASSERT_EQ(feld[1], nullptr);

    //Überwachung beenden
    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(erstelleWortFeld, space_word) {
    char** feld;

    //Speicherüberwachung starten
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();

    //Darf keine Exception werfen.
    ASSERT_NO_THROW(feld = erstelleWortFeld(STRING_SPACE_WORD));

    //Gibt einen Zeiger auf ein Feld zurück
    ASSERT_NE(feld, nullptr);

    //Es muss zweimal Speichern reserviert worden sein
    //Einmal für das Feld und einmal für das eine vorhandene Wort
    ASSERT_EQ(snapshot->count(), 2);

    //Das Feld hat 2 Einträge
    ASSERT_EQ((*snapshot)[feld].getSize(), 2 * sizeof(char*));

    //Das Wort hat eine Länge von 4 + 1 für '\0'
    ASSERT_EQ((*snapshot)[feld[0]].getSize(), 5 * sizeof(char));

    //Und es muss sich um Arrays handeln
    ASSERT_TRUE((*snapshot)[feld].isArray());
    ASSERT_TRUE((*snapshot)[feld[0]].isArray());

    //Das Feld enthält einen Zeiger auf den String "Wort" an Stelle 0
    ASSERT_STREQ(feld[0],"Wort");

    //...und and er Stelle 1 den nullptr
    ASSERT_EQ(feld[1], nullptr);

    //Überwachung beenden
    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(erstelleWortFeld, string_all) {
    char** feld;

    //Speicherüberwachung starten
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();

    //Darf keine Exception werfen.
    ASSERT_NO_THROW(feld = erstelleWortFeld(STRING_ALL));

    //Gibt einen Zeiger auf ein Feld zurück
    ASSERT_NE(feld, nullptr);

    //Es muss zweimal Speichern reserviert worden sein
    //Einmal für das Feld und einmal für das eine vorhandene Wort
    ASSERT_EQ(snapshot->count(), 5);

    //Das Feld hat 5 Einträge
    ASSERT_EQ((*snapshot)[feld].getSize(), 5 * sizeof(char*));

    //Prüfen der Wortlängen
    ASSERT_EQ((*snapshot)[feld[0]].getSize(), 5 * sizeof(char));
    ASSERT_EQ((*snapshot)[feld[1]].getSize(), 4 * sizeof(char));
    ASSERT_EQ((*snapshot)[feld[2]].getSize(), 4 * sizeof(char));
    ASSERT_EQ((*snapshot)[feld[3]].getSize(), 6 * sizeof(char));

    //Und es muss sich um Arrays handeln
    ASSERT_TRUE((*snapshot)[feld].isArray());
    ASSERT_TRUE((*snapshot)[feld[0]].isArray());
    ASSERT_TRUE((*snapshot)[feld[1]].isArray());
    ASSERT_TRUE((*snapshot)[feld[2]].isArray());
    ASSERT_TRUE((*snapshot)[feld[3]].isArray());

    //Das Feld enthält Zeiger auf die Worte
    ASSERT_STREQ(feld[0],"Dies");
    ASSERT_STREQ(feld[1],"ist");
    ASSERT_STREQ(feld[2],"ein");
    ASSERT_STREQ(feld[3],"Test!");

    //...und an der Stelle 4 den nullptr
    ASSERT_EQ(feld[4], nullptr);

    //Überwachung beenden
    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(loescheWortFeld, nullptr) {
    //Keine Exception bei nullptr
    ASSERT_NO_THROW(loescheFeld(nullptr));
}

TEST(loescheWortFeld, space) {
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();

    //Dieses Feld würde mit dem STRING_SPACE erzeugt werden
    char** feld = new char*[1];
    feld[0] = nullptr;

    snapshot->setAbortOnWrongDelete();
    ASSERT_NO_THROW(loescheFeld(feld)); //Darf hier nicht abstürzen oder abbrechen
    ASSERT_EQ(snapshot->count(),0); //Es darf kein Speicher überbleiben
    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(loescheWortFeld, ein_wort) {
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();

    //Dieses Feld würde mit dem STRING_SPACE erzeugt werden
    char** feld = new char*[2];
    feld[0] = new char[5];
    feld[1] = nullptr;
    feld[0][0] = 'W';
    feld[0][1] = 'o';
    feld[0][2] = 'r';
    feld[0][3] = 't';
    feld[0][4] = '\0';

    snapshot->setAbortOnWrongDelete();
    ASSERT_NO_THROW(loescheFeld(feld)); //Darf hier nicht abstürzen oder abbrechen
    ASSERT_EQ(snapshot->count(),0); //Es darf kein Speicher überbleiben
    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(loescheWortFeld, ein_satz) {
    MemorySnapshot* snapshot = memoryMonitor.createSnapshot();

    //Dieses Feld würde mit dem STRING_ALL erzeugt werden
    char** feld = new char*[5];
    feld[0] = new char[5];
    feld[1] = new char[4];
    feld[2] = new char[4];
    feld[3] = new char[6];
    feld[4] = nullptr;

    feld[0][0] = 'W';
    feld[0][1] = 'o';
    feld[0][2] = 'r';
    feld[0][3] = 't';
    feld[0][4] = '\0';

    feld[1][0] = 'i';
    feld[1][1] = 's';
    feld[1][2] = 't';
    feld[1][3] = '\0';

    feld[2][0] = 'e';
    feld[2][1] = 'i';
    feld[2][2] = 'n';
    feld[2][3] = '\0';

    feld[3][0] = 'T';
    feld[3][1] = 'e';
    feld[3][2] = 's';
    feld[3][3] = 't';
    feld[3][4] = '!';
    feld[3][5] = '\0';

    snapshot->setAbortOnWrongDelete();
    ASSERT_NO_THROW(loescheFeld(feld)); //Darf hier nicht abstürzen oder abbrechen
    ASSERT_EQ(snapshot->count(),0); //Es darf kein Speicher überbleiben
    memoryMonitor.deleteSnapshot(snapshot);
}

TEST(tauscheWorte, tauschen) {
    char str1[] = "Test";
    char str2[] = "Foobar";

    char* ptr1 = str1;
    char* ptr2 = str2;

    tauscheWorte(ptr1, ptr2);

    //Pointer müssen vertauscht worden sein
    ASSERT_EQ(ptr1, str2);
    ASSERT_EQ(ptr2, str1);
}