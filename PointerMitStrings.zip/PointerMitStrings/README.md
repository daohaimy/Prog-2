**_Zeichenkettenbearbeitung mit Pointern_**
-----

Aufgabe ist es einen String (gegeben als char*, auch C-string oder null terminierter string genannt) in seine Wörter zu
zerlegen und diese in einem Feld zu speichern, sodass über den Index des Feldes auf die einzelnen Wörter zugegriffen
werden kann. Das Feld beinhaltet Zeiger auf die Wörter.
Der Speicher für dieses Feld, sowie der Speicher für die Wörter, sollen mit **new[]** erzeugt werden. Der letzte
Eintrag soll ein nullptr-Zeiger sein, damit es möglich ist durch das Feld zu iterieren, ohne die Länge zu wissen. Aus dem
gleichen Grund sind C-strings mit dem '\0'Zeichen terminiert.

Die Aufgabe ist in einzelne Schritte zerlegt:

A) Erstellen Sie eine Funktion **sucheWortEnde**, die einen Zeiger auf eine Zeichenkette erhält und durch diese iteriert 
bis ein Leerzeichen, und damit das Ende eines Wortes, gefunden wird. Der Zeiger auf dieses Leerzeichen wird 
zurückgegeben. Wird das Ende der Zeichenkette erreicht, markiert durch das '\0'-Zeichen, soll der Zeiger
auf dieses '\0'-Zeichen zurückgegeben werden. Damit zeigt der Rückgabewert immer auf das erste Zeichen *hinter* dem Wort.  

B) Erstellen Sie eine Funktion **sucheWortAnfang**, die einen Zeiger auf eine Zeichenkette erhält und durch diese 
iteriert bis ein NICHT-Leerzeichen, und damit der Anfang eines Wortes, gefunden wird. Der Zeiger auf dieses Zeichen 
wird zurückgegeben. Beim Erreichen des Endes wird wieder der Zeiger auf das '\0'-Zeichen zurückgegeben.

C) Erstellen Sie eine Funktion **zaehleWorte**, die die Anzahl der Worte in einem String ermittelt. Nutzen Sie dazu die 
Funktion aus A und B

D) Dann erstellen Sie die Hauptfunktion **erstelleWortFeld**, die eine Zeichenkette übergeben bekommt und ein Feld mit 
Zeigern auf die Worte zurückgibt. Hier wird Speicher für das Feld und die Wörter (mit **new[]**) angelegt und 
dann jedes Wort kopiert und der Zeiger darauf in das Feld eingefügt. Benutzen Sie die Hilfsfunktionen aus A, B und C.

E) Implementieren Sie eine Funktion **feldAusgeben**, welche alle Worte eines übergebenen Feldes mit **cout** auf 
der Konsole ausgibt.

F) Erstellen Sie eine Funktion **tauscheWorte**, die zwei Worte in einem Feld vertauscht. Dabei sollen nur die 
Zeiger und nicht die tatsächlichen Worte vertauscht werden. Verwenden Sie hier Referenzen auf die Wortzeiger um diese zu 
vertauschen. (Siehe Vorlesungsfolien zu Zeigern)

G) Erstellen Sie zuletzt eine Funktion **loescheFeld**, die den reservierten Speicher eines Feldes und der Worte wieder 
mit **delete[]** löscht.

H) **OPTIONAL** Achten Sie auf korrekte Verwendung des const-Schlüsselworts. 

Der Code der main() Funktion ist gegeben mit...

    char satz[] = "  Dies ist    ein String!  ";
    char** feld = erstelleWortFeld(satz);

    feldAusgeben(feld);

    tauscheWorte(feld[0], feld[2]);
    tauscheWorte(feld[1], feld[3]);

    feldAusgeben(feld);
    loescheFeld(feld);


...und produziert folgende Ausgabe:

    Dies ist ein String!
    ein String! Dies ist
