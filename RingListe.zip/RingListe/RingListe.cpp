#include "RingListe.h"
using namespace std;

RingListe::RingListe(): werte(10) {
    groesse = 10;
}

RingListe::RingListe(int anzahl): werte(anzahl){
    groesse = anzahl;

}

string RingListe::toString() {
    string zahlen = "";
    size_t i2 = groesse;
    for(size_t i = 0; i < groesse; i++){
        zahlen = zahlen + to_string(werte[i])+ " ";
        if(werte[i] == 0){
            i2--;
        }
    }
    return "Belegung: " + to_string(i2) + "/" + to_string(groesse) + " |"+zahlen + "| lesePos=" + to_string(lese) + " schreibPos=" + to_string(schreibe);
}

RingListe& RingListe::operator<<(int wert) {
    if(counter != 0 && schreibe == lese){
        lese++;
        if (lese == groesse){
            lese = 0;
        }
        werte[schreibe] = wert;
        schreibe++;
    } else{
        werte[schreibe] = wert;
        schreibe++;
        counter++;
    }

    if (schreibe == groesse) {
        schreibe = 0;
    }
    return *this;
}

RingListe& RingListe::operator>>(int& wert) {
    if(counter > 0){
        if(lese == groesse){
            lese = 0;
            wert = werte[lese];
            werte[lese] = 0;
            lese++;
            counter--;
        } else{
            wert = werte[lese];
            werte[lese] = 0;
            lese++;
            counter--;
        }
    }
    else{
        throw ReadEmptyRingListException();
    }
    return *this;
}

bool RingListe::operator==(const RingListe rl) const {
    if (counter != rl.counter) {
        return false;
    }

    for (size_t i = 0; i < counter; i++) {
        if (werte[(lese+i) % groesse] != rl.werte[(rl.lese+i) % rl.groesse]) {
            return false;
        }
    }
    return true;

}

RingListe& RingListe::operator+=(int wert) {
    for (size_t i = 0; i < groesse; i++) {
        schreibe++;
        if(schreibe == groesse){
            schreibe = 0;
        }
        werte[schreibe] += wert;
    }
    return *this;
}

RingListe& RingListe::operator<<(RingListe& rl) {
    //size_t u = rl.lese;

    for (size_t i = 0; i < rl.counter; i++){
            if(rl.lese == rl.groesse){
                rl.lese = 0;
            }
            *this << rl.werte[(rl.lese+i)%rl.groesse];
            //u++;
    }
    return *this;
}