#pragma once
#include <vector>
#include "string"
using namespace std;

class ReadEmptyRingListException {
};

class RingListe {
    vector<int> werte;
    size_t groesse;
    size_t schreibe = 0;
    size_t lese = 0;
    size_t counter = 0;
public:
    RingListe();
    RingListe(int werte);
    string toString();
    RingListe& operator<<(int wert);
    RingListe& operator>>(int& wert);
    bool operator==(const RingListe rl) const;
    RingListe& operator+=(int wert);
    RingListe& operator<<(RingListe& rl);
};


