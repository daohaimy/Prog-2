#include <regex>

#include "gtest/gtest.h"
#include "../RingListe.h"

TEST(BasicTests, EmptyRingListToString){
    RingListe rl;
    RingListe rl5(5);

    //Eine Liste ohne Parameter im ctor erstellt eine leere Liste mit einer Kapazität von 10
    //und die toString() sollte genau so aussehen
    ASSERT_STREQ(rl.toString().c_str(),"Belegung: 0/10 |0 0 0 0 0 0 0 0 0 0 | lesePos=0 schreibPos=0");

    //toString(), wenn die Kapazität mit 5 festgelegt wurde
    ASSERT_STREQ(rl5.toString().c_str(),"Belegung: 0/5 |0 0 0 0 0 | lesePos=0 schreibPos=0");
}

TEST(BasicTests, WriteAndReadOne) {
    RingListe rl;
    int result = 0;

    //Einen Wert schreiben und genau diesen Wert wieder lesen
    rl << 42;
    rl >> result;

    ASSERT_EQ(result, 42);
}

TEST(BasicTests, WriteAndReadOneZero) {
    RingListe rl;
    int result = 42;

    //Auch eine 0 ist ein gültiger Wert!
    rl << 0;
    rl >> result;

    ASSERT_EQ(result, 0);
}

TEST(BasicTests, WriteAndReadThree) {
    RingListe rl;
    int result = 42;

    //3 Werte schreiben und wieder lesen
    rl << 1 << 2 << 3;

    rl >> result;
    ASSERT_EQ(result, 1);

    rl >> result;
    ASSERT_EQ(result, 2);

    rl >> result;
    ASSERT_EQ(result, 3);
}

TEST(BasicTests, WriteAndReadFullList){
    RingListe rl(5);
    int r1,r2,r3,r4,r5;

    //5 Werte schreiben und in der korrekte Reihenfolge auslesen.
    //Die RingListe wird dann einmal komplett voll und wieder leer
    rl << 0 << 1 << 0 << 2 << 0;
    rl >> r1 >> r2 >> r3 >> r4 >> r5;

    ASSERT_EQ(r1,0);
    ASSERT_EQ(r2,1);
    ASSERT_EQ(r3,0);
    ASSERT_EQ(r4,2);
    ASSERT_EQ(r5,0);
}

TEST(BasicTests, ReadFromNewEmptyList) {
    RingListe rl;
    int wert;

    //Das Lesen aus einer leeren Liste muss eine ReadEmptyRingListException werfen
    ASSERT_THROW(rl >> wert,ReadEmptyRingListException);
}

TEST(BasicTests, ReadFromEmptiedList) {
    RingListe rl(5);
    int wert;

    //Liste komplett füllen und wieder leeren
    for(size_t i = 0; i < 5; i++) rl << i;
    for(size_t i = 0; i < 5; i++) rl >> wert;

    //Das Lesen aus einer erneut leeren Liste muss eine Exception werfen
    ASSERT_THROW(rl >> wert,ReadEmptyRingListException);
}

TEST(AdvancedTests, OverwriteTwoElements) {
    RingListe rl(5);
    int r1 = 0;
    int r2 = 0;

    rl << 1 << 2 << 3 << 4 << 5 << 6 << 7;
    rl >> r1 >> r2;

    //Zweimal in eine volle Liste schreiben! Die Werte 1 und 2 werden überschrieben mit 6 und 7.
    //Der Lesezeiger muss zweimal "mitgenommen" werden, damit er wieder an die korrekte Stelle zeigt.
    //(nämlich auf den ältesten Wert)

    ASSERT_EQ(r1, 3);
    ASSERT_EQ(r2, 4);
}

TEST(AdvancedTests, CompareListEasy) {
    RingListe rl1(5);
    RingListe rl2(5);
    int wert;

    rl1 << 1 << 2 << 3;
    rl2 << 4 << 5 << 1 << 2 << 3;
    rl2 >> wert >> wert;

    //Beide Listen enthalten noch 3 Elemente mit den Werten 1,2 und 3
    ASSERT_EQ(rl1 == rl2, true);
}
TEST(AdvancedTests, CompareListMedium) {
    RingListe rl1(5);
    RingListe rl2(5);
    int wert;

    //Listen mit Umbrüchen vergleichen
    //Modulo(Umbruch) muss funktionieren
    rl1 << 5 << 5 << 5 << 1 << 2 << 3 >> wert >> wert;
    rl2 << 5 << 1 << 2 << 3 >> wert;

    //Müssen gleich sein
    ASSERT_EQ(rl1 == rl2, true);
}

TEST(AdvancedTests, CompareListHard) {
    RingListe rl1(5);
    RingListe rl2(7);
    int wert;

    //Listen mit unterschiedlichen Kapazitäten, Null-Werten und unterschiedlichen Umbrüchen
    rl1 << 5 << 5 << 5 << 0 << 1 << 2 << 3 >> wert;
    rl2 << 5 << 5 << 5 << 0 << 0 << 1 << 2 << 3 >> wert >> wert >> wert;

    //Müssen gleich sein
    ASSERT_EQ(rl1 == rl2, true);
}

TEST(AdvancedTests, CompareListCorrectCompareCount) {
    RingListe rl1(3);
    RingListe rl2(7);
    int wert;

    //Testet, ob Kapazität statt Belegung als Zähler variable verwendet wird
    rl1 << 11 << 22 << 33;
    rl2 << 0 << 0 << 11 << 22 << 33 >> wert >> wert;

    //Müssen gleich sein, in beide Richtungen
    ASSERT_EQ(rl1 == rl2, true);
    ASSERT_EQ(rl2 == rl1, true);
}

TEST(AdvancedTests, CompareListSelf) {
    RingListe rl(5);

    rl << 0 << 1 << 2 << 3;
    ASSERT_TRUE(rl == rl);
}

TEST(AdvancedTests, CompareConstListWithConstList) {
    RingListe rl(5);
    RingListe rl2(5);

    int wert;
    rl << 1 << 2 << 3;
    rl2 << 0 << 1 << 2 << 3 >> wert;

    const RingListe& crl = rl;
    const RingListe& crl2 = rl2;

    ASSERT_TRUE(crl == crl2);
}

TEST(AdvancedTests, CompareListUnequal) {
    RingListe rl1(5);
    RingListe rl2(7);
    int wert;

    //Der Vergleich von ungleichen Listen muss false zurückgeben
    rl1 << 5 << 5 << 5 << 0 << 1 >> wert >> wert >> wert;
    rl2 << 5 << 5 << 5 << 0 << 0 << 1 << 2 << 3 >> wert >> wert >> wert >> wert >> wert;

    //Dürfen NICHT gleich sein
    ASSERT_FALSE(rl1 == rl2);
}

TEST(AdvancedTests, CompareListUnequalEmpty) {
    RingListe rl1(5);
    RingListe rl2(7);
    int wert;

    //Der Vergleich von ungleichen Listen muss false zurückgeben
    rl1 << 5 << 5 << 5 >> wert >> wert;
    rl2 << 5 << 5 << 5 << 0 << 0 >> wert >> wert >> wert >> wert >> wert;

    //Dürfen NICHT gleich sein
    ASSERT_FALSE(rl1 == rl2);
}

TEST(AdvancedTests,CompareList_UnequalButSameInternalData) {
    RingListe rl1(5);
    RingListe rl2(5);
    int wert;

    //Nach außen sind die beiden Listen nicht gleich,
    //aber intern hat der vector dieselben Daten
    rl1 << 0 << 1 << 0 << 0 >> wert;
    rl2 << 0 << 0 << 1 << 0 >> wert >> wert;

    //Die beiden Listen sind NICHT gleich.
    //Aus rl1 kann 1, 0, 0 gelesen werden.
    //Aus rl2 kann 1, 0 gelesen werden
    ASSERT_EQ(rl1 == rl2, false);
    ASSERT_EQ(rl2 == rl1, false);
}

TEST(AdvancedTests, CompareListConst) {
    RingListe rl1(5);
    RingListe rl2(7);

    rl1 << 1 << 2 << 3;
    rl2 << 1 << 2 << 3;

    //Erstellen einer konstanten RingListe mit den Werten von rl2
    //Sie brauchen keinen Kopierkontruktor programmieren, da dieser automatisch angelegt wird
    const RingListe constRL(rl2);

    //Auch der Vergleich mit einer konstanten RingListe soll möglich sein.
    //Was bedeutet das für (eventuell) für Ihren Vergleichsoperator?
    ASSERT_TRUE(rl1 == constRL);
}

TEST(AdvancedTests, OperatorPlus) {
    RingListe rl(5);
    int wert;

    //Operator+ auf folgender Liste:
    //L     x
    //  0 0 0 1 0
    //S   x

    //erzeugt folgende Liste
    //L     x
    //  3 0 3 4 3
    //S   x

    rl << 0 << 3 << 0 << 1 << 0 << 0 >> wert;
    rl +=3;

    rl >> wert;
    ASSERT_EQ(wert, 3);
    rl >> wert;
    ASSERT_EQ(wert, 4);
    rl >> wert;
    ASSERT_EQ(wert, 3);
    rl >> wert;
    ASSERT_EQ(wert, 3);
}

TEST(AdvancedTests, ConcatenateTwoLists) {
    RingListe rl1(5);
    RingListe rl2;
    int wert;

    //L         x
    //  2 3 0 0 1
    //S     x
    rl1 << 0 << 0 << 0 << 0 << 1 << 2 << 3 >> wert >> wert;

    //L                 x
    //  3 0 0 0 0 0 0 0 1 2
    //S   x
    rl2 << 0 << 0 << 0 << 0 << 0 << 0 << 0 << 0 << 1 << 2 << 3;
    rl2 >> wert >> wert >> wert >> wert >> wert >> wert >> wert;

    //L x
    //  2 3 1 2 3
    //S x
    rl1 << rl2;
    rl1 >> wert;
    ASSERT_EQ(wert,2);
    rl1 >> wert;
    ASSERT_EQ(wert,3);
    rl1 >> wert;
    ASSERT_EQ(wert,1);
    rl1 >> wert;
    ASSERT_EQ(wert,2);
    rl1 >> wert;
    ASSERT_EQ(wert,3);
}

TEST(AdvancedTests, CheckForMemoryLeak) {
    RingListe rl;

    //10 Millionen Werte schreiben.
    //Die alten Werte werden also immer wieder überschrieben, da niemals gelesen wird
    //Falls die zyklische Struktur nicht beachtet wurde, stürzt das Programm hier ab
    for(int i = 0; i < 10000000; ++i) {
        rl << i;
    }
}
