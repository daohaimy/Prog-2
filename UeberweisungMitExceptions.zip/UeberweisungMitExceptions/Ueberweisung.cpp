#include <iostream>
#include <string>

#include "Ueberweisung.h"

using namespace std;

int extrahiereKontonummer(string kontonummer) {

    // NummerNichtNumerischeKontonummer
    for (int i = 0; i < kontonummer.length() - 1; i++) {
        if (isalpha(kontonummer[i])) {
            throw UngueltigeKontonummer();
        }
    }
    /*
    int letzteZahl;
    try{letzteZahl = stoi(kontonummer)} catch(...){
     }
     */




    // Quersumme rechnen
    int quersumme = 0;
    for (int i = 0; i < kontonummer.length() - 1; i++) {
        quersumme = quersumme + (kontonummer[i] - '0');
    }
    if (quersumme > 9) {
        quersumme = quersumme % 10 + quersumme / 10;
    }
    int letzteZahl = stoi(kontonummer);
    letzteZahl = letzteZahl % 10;
    if (quersumme == letzteZahl) {
        int ergebnis = stoi(kontonummer);
        ergebnis /= 10;
        return ergebnis;
    } else {
        throw UngueltigeKontonummer();
    }
}


void ueberweiseGeld(int& kontostand, int betrag, string kontonummer) {
    if(kontostand < betrag){
        throw NichtGenugGeld();
    }
    else{
        extrahiereKontonummer(kontonummer);
        kontostand -= betrag;
    }
}

/*
    char* nummer = new char[kontonummer.length()-1];
    for (int i = 0; i < kontonummer.length()-1; i++){
        nummer[i] = kontonummer[i];
    }
    string ss(nummer);

    char* nummer3 = new char[kontonummer.length()];
    for (int i = 0; i < kontonummer.length(); i++){
        nummer3[i] = kontonummer[i];
    }
    int letzteNummer = (int) nummer3[kontonummer.length()-1];
*/

/*
    // NummerFalschePruefsumme
    int summe = 0;
    for(int i = 0; i < ss.length(); i++){
        summe += (int) ss[i];
    }
    string summeToString = to_string(summe);
    const char* quersummeArray = summeToString.c_str();
    int quersumme1 = 0;
    for(int i = 0; i < summeToString.length(); i++){
        quersumme += (int) quersummeArray[i];
    }
    if(quersumme != letzteNummer){
        throw UngueltigeKontonummer();
    }
    else{
        int ergebnis = stoi(ss);
        return ergebnis;
    }
}
 */
