#pragma once

#include <string>

using namespace std;

struct NichtGenugGeld {
    string kto;
};

struct UngueltigeKontonummer {
    string grund;
};

int extrahiereKontonummer(string kontonummer);
void ueberweiseGeld(int& kontostand, int betrag, string kontonummer);
