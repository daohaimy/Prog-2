**Geldüberweisung mit Ausnahmebehandlung**
--

Schreiben Sie eine Funktion **ueberweiseGeld**, die als Parameter einen *Kontostand* als Referenz auf **int**, einen *Betrag* als **int**
und eine *Kontonummer* als **string** übergeben bekommt. Diese Funktion ruft eine weitere Funktion 
**extrahiereKontonummer** auf. Dort wird zunächst mit der vorhandenen STL-Funktion **stoi()** der String 
in eine Zahl konvertiert. Eine Kontonummer ist dann korrekt, wenn Ihre enthaltene Prüfsumme korrekt ist. Diese Prüfsumme
entspricht der Einerstelle, die der iterierten Quersumme der restlichen Zahl entsprechen muss.

Beispiel:

> Kontonummer als String: "123456"<br />
Kontonummer als int: 123456;<br />
Einerstelle: 6;<br />
Quersumme von 12345 = 1 + 2 + 3 + 4 + 5 = 15 => 1 + 5 = 6

Ist die Quersumme ungleich der Prüfsumme, soll die Ausnahme **UngueltigeKontonummer** geworfen werden. Die Ausnahme soll
den Grund als Textnachricht enthalten. Ansonsten wird die Kontonummer ohne Prüfsumme als **int** zurückgegeben.
Alle Exceptions sind bereits als globales **struct** angelegt worden:

    struct UngueltigeKontonummer {
        string Grund;
    };
    struct NichtGenugGeld {
        string kontonummer;
    };

Die Funktion **ueberweiseGeld** überprüft bei korrekter Kontonummer, ob der Kontostand ausreichend ist und subtrahiert
Betrag von Kontostand. Ist der Kontostand zu niedrig, wird eine Ausnahme **NichtGenugGeld** geworfen, die die Kontonummer
als String enthält. Eine **main()** Funktion ist vorgegeben und sieht folgendermaßen aus:

    int main() {
        int kontostand = 100;
    
        try {
            ueberweiseGeld(kontostand, 30, "123456");
            ueberweiseGeld(kontostand, 40, "123456");
            ueberweiseGeld(kontostand, 30, "123459");   //Falsche Kontonummer
            ueberweiseGeld(kontostand, 30, "DE123456"); //Falsche Kontonummer
            ueberweiseGeld(kontostand, 40, "123456");   //Nicht genug Geld
        }
        catch(NichtGenugGeld &ex) {
            cout << "Kontostand auf Konto: " << ex.kto << " nicht ausreichend!" << endl;
        }
        catch(UngueltigeKontonummer &ex) {
            cout << "Ungültige Kontonummer! Grund: " << ex.grund << endl;
        }
    }

Testen Sie ihre Funktion **ueberweiseGeld** mit der **main** Funktion und den **Tests**. Müssen Sie noch weitere Exceptions
beachten?