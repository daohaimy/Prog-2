#include <iostream>
#include <string>

#include "Ueberweisung.h"

using namespace std;

int extrahiereKontonummer(string kontonummer2) {

    for (int i = 0; i < kontonummer2.length(); i++){
        if (!isdigit(kontonummer2[i])){
            throw UngueltigeKontonummer();
        }
    }

    int kontonummer = stoi(kontonummer2);
    int quersumme = 0;
    int richtig = kontonummer;
    int überprüfung = kontonummer % 10;
    kontonummer = kontonummer / 10;
    while (kontonummer != 0){
        quersumme = quersumme + kontonummer % 10;
         kontonummer = kontonummer / 10;
    }
    if (quersumme >= 100){
        quersumme = (quersumme % 10) + ((quersumme / 10) / 10) + ((quersumme / 10) % 10);
    }
    while (quersumme > 9 && quersumme < 100){
        quersumme = (quersumme % 10) + (quersumme / 10);
    }
    if (überprüfung == quersumme){
        cout << "richtige Kontonummer" << endl;
        return richtig / 10;
    } else {
        throw UngueltigeKontonummer();
    }

}

void ueberweiseGeld(int& kontostand, int betrag, string kontonummer) {
    if (kontostand < betrag){
        throw NichtGenugGeld();
    }
    extrahiereKontonummer(kontonummer);

    kontostand = kontostand - betrag;

}