#include <iostream>

#include "gtest/gtest.h"
#include "../Ueberweisung.h"

using namespace std;

TEST(ExtrahiereKontonummer, NummerKorrekt) {
    try {
        //Die Kontonummer ist korrekt und es muss die Zahl ohne die letzte Ziffer zurückgegeben werden
        int result = extrahiereKontonummer("123456");
        ASSERT_EQ(result, 12345);
        result = extrahiereKontonummer("721458549");
        ASSERT_EQ(result, 72145854);
    }
    catch(...) {
        //Eine korrekte Kontonummer darf keine Exception werfen
        FAIL();
    }
}

TEST(ExtrahiereKontonummer, NummerFalschePruefsumme) {
    try {
        //Die Kontonummer ist korrekt und es muss die Zahl ohne die letzte Ziffer zurückgegeben werden
        extrahiereKontonummer("123459");

        //Das Programm darf nicht hier ankommen, da es eine Exception geben muss
        FAIL();
    }
    catch (UngueltigeKontonummer &ex) {
        //Die korrekte Exception wurde geworfen.
        //Der Grund sollte in ex.grund stehen.
        cout << ex.grund << endl;
    }
    catch(...) {
        //Jede andere Exception ist nicht korrekt
        FAIL();
    }
}

TEST(ExtrahiereKontonummer, NummerNichtNumerischeKontonummer) {
    try {
        //Die Kontonummer ist keine Zahl
        extrahiereKontonummer("DE123456");

        //Das Programm darf nicht hier ankommen, da es eine Exception geben muss
        FAIL();
    }
    catch (UngueltigeKontonummer &ex) {
        //Die korrekte Exception wurde geworfen.
        //Der Grund sollte in ex.grund stehen.
        cout << ex.grund << endl;
    }
    catch(...) {
        //Jede andere Exception ist nicht korrekt.
        FAIL();
    }
}

TEST(UeberweiseGeld, GenugGeldKeineException) {
    int geld = 100;

    try {
        ueberweiseGeld(geld, 20, "123456");
    }
    catch (...) {
        //Überweisung sollte erfolgreich sein und kein Exception werfen
        FAIL();
    }
}

TEST(UeberweiseGeld, GenugGeldBetragReduziert) {
    int geld = 100;

    try {
        ueberweiseGeld(geld, 20, "123456");
        ASSERT_EQ(geld, 80);
    }
    catch (...) {
        //Überweisung sollte erfolgreich sein und kein Exception werfen
        FAIL();
    }
}

TEST(UeberweiseGeld, NichtGenugGeld) {
    int geld = 100;

    try {
        ueberweiseGeld(geld, 120, "123456");

        //Das Programm darf hier nicht ankommen, da es eine Exception geben muss
        FAIL();
    }
    catch(NichtGenugGeld &ex) {
        //Korrekte Exception wurde geworden
        cout << "Nicht genug Geld auf: " << ex.kto << endl;
    }
    catch (...) {
        //Es darf keine andere Exception geworfen werden.
        FAIL();
    }
}

TEST(UeberweiseGeld, FalscheKontonummer) {
    int geld = 100;

    try {
        ueberweiseGeld(geld, 20, "123459");
        FAIL();
    }
    catch(UngueltigeKontonummer &ex) {
        //Korrekte Exception wurde geworden
        cout << ex.grund << endl;
    }
    catch (...) {
        //Es darf keine andere Exception geworfen werden.
        FAIL();
    }

    try {
        ueberweiseGeld(geld, 20, "DE123456");
        FAIL();
    }
    catch(UngueltigeKontonummer &ex) {
        //Korrekte Exception wurde geworden
        cout << ex.grund << endl;
    }
    catch (...) {
        //Es darf keine andere Exception geworfen werden.
        FAIL();
    }
}