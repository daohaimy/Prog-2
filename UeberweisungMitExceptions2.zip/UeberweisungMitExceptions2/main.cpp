#include <iostream>
#include <string>

#include "Ueberweisung.h"

using namespace std;

int main() {
    int kontostand = 100;

    try {
        ueberweiseGeld(kontostand, 30, "123456");
        ueberweiseGeld(kontostand, 40, "123456");
        ueberweiseGeld(kontostand, 30, "123459");   //Falsche Kontonummer
        ueberweiseGeld(kontostand, 30, "DE123456"); //Falsche Kontonummer
        ueberweiseGeld(kontostand, 40, "123456");   //Nicht genug Geld
    }
    catch(NichtGenugGeld &ex) {
        cout << "Kontostand auf Konto: " << ex.kto << " nicht ausreichend!" << endl;
    }
    catch(UngueltigeKontonummer &ex) {
        cout << "Ungueltige Kontonummer! Grund: " << ex.grund << endl;
    }
}