//
// Created by kevin_njxn11i on 24.04.2023.
//
#include "besitztMehrWorteAls.h"
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

besitztMehrWorteAls::besitztMehrWorteAls(string wort) {
    istringstream wortSS(wort);
    string uebergeben;
    while (wortSS >> uebergeben){
        anzahlWorte++;
    }
}

bool besitztMehrWorteAls::operator()(std::string vergleich) const {
    size_t zaehler = 0;
    istringstream vergleichSS(vergleich);
    string uebergeben2;
    while (vergleichSS >> uebergeben2){
        zaehler++;
    }
    return anzahlWorte < zaehler;
}
