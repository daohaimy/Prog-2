//
// Created by kevin_njxn11i on 24.04.2023.
//

#ifndef KEMY_BESITZTMEHRWORTEALS_H
#define KEMY_BESITZTMEHRWORTEALS_H
#include <string>

#endif //KEMY_BESITZTMEHRWORTEALS_H

using namespace std;
class besitztMehrWorteAls {
    size_t anzahlWorte;
    string gespeichertesWort;
public:
    besitztMehrWorteAls(string wort);
    bool operator()(string vergleich) const;
};