//
// Created by haimydao on 4/24/2023.
//
#include "istKuerzerAls.h"
#include <string>
using namespace std;

bool istKuerzerAls::operator()(string s1, string s2) const{
    return s1.length() < s2.length();
}