//
// Created by haimydao on 4/24/2023.
//

#ifndef KEMY_ISTKUERZERALS_H
#define KEMY_ISTKUERZERALS_H

#endif //KEMY_ISTKUERZERALS_H
#include <string>
using namespace std;

class istKuerzerAls{
public:
    bool operator()(string s1, string s2) const;
};