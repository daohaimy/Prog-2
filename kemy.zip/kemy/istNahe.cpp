//
// Created by haimydao on 4/24/2023.
//
#include "istNahe.h"
using namespace std;

istNahe::istNahe(double tolerance){
    this->tolerance = tolerance;
}

bool istNahe::operator()(double s1, double s2) const {
    double abstand = 0;
    if(s1 >= s2){
        abstand = s1-s2;
    }else{
        abstand = s2-s1;
    }
    return !(abstand > tolerance);
}
