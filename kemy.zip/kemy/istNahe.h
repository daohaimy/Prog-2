//
// Created by haimydao on 4/24/2023.
//

#ifndef KEMY_ISTNAHE_H
#define KEMY_ISTNAHE_H

#endif //KEMY_ISTNAHE_H
using namespace std;

class istNahe{
    double tolerance = 0.0001;
public:
    istNahe(double tolerance);
    bool operator()(double s1, double s2) const;

};


