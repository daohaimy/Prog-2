//
// Created by kevin_njxn11i on 19.04.2023.
//
#include "istTeilerVon_n.h"

using namespace std;

istTeilerVon_n::istTeilerVon_n(int n):t(n){}

bool istTeilerVon_n::operator()(int z) const {
    return !(z % t);
}

