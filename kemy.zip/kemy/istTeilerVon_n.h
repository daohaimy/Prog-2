//
// Created by kevin_njxn11i on 19.04.2023.
//

#include <system_error>

#ifndef KEMY_PROJEKT_H
#define KEMY_PROJEKT_H

#endif //KEMY_PROJEKT_H
class istTeilerVon_n {
    int t;
public:
    istTeilerVon_n(int n);
    bool operator()(int z) const;
};