//
// Created by kevin_njxn11i on 19.04.2023.
//
#include "iostream"
#include "istTeilerVon_n.h"
using namespace std;
#include "istNahe.h"

int main(){
    istNahe test(10.0);
    cout << boolalpha << test(10.0, 11.1) << endl;
    return 0;
}